(function(g) {
	//----------------------------------------------------
	// Invitation-related methods.

	g.generateInvitationToken = function(size, groupID, onCallback) {
		g.sender.invoke(
			"/user/invitation/generate?size=" + size + "&group=" + groupID,
			true,
			function(resp) {
				if (resp.status === 0) {
					g.queryInvitationToken(onCallback);
				} else {
					if (g.isFunction(onCallback)) {
						onCallback(resp);
					}
				}
			}
		);
	};
	g.deleteInvitationToken = function(token, onCallback) {
		g.sender.invoke(
			"/user/invitation/delete?id=" + encodeURIComponent(token),
			true,
			function(resp) {
				if (resp.status === 0) {
					g.queryInvitationToken(onCallback);
				} else {
					if (g.isFunction(onCallback)) {
						onCallback(resp);
					}
				}
			}
		);
	};
	g.queryInvitationToken = function(onCallback) {
		g.sender.invoke(
			"/user/invitation/query",
			true,
			function(resp) {
				if (resp.status === 0) {
					g.data.invitationTokens = resp.result.token;
				}
				if (g.isFunction(onCallback)) {
					onCallback(resp);
				}
			}
		);
	};

	//----------------------------------------------------
	// Group-related methods.

	var onGroupCallback = function(onCallback) {
		return function(resp) {
			if (resp.status === 0) {
				g.queryGroup(onCallback);
			} else {
				if (g.isFunction(onCallback)) {
					onCallback(resp);
				};
			}
		};
	};

	g.addGroup = function(groupName, onCallback) {
		g.sender.invoke(
			"/user/group/add?name=" + encodeURIComponent(groupName),
			true,
			onGroupCallback(onCallback)
		);
	};
	g.deleteGroup = function(groupID, onCallback) {
		g.sender.invoke(
			"/user/group/delete?id=" + groupID,
			true,
			onGroupCallback(onCallback)
		);
	};
	
	g.getInternalIP = function(onCallback) {
		g.sender.invoke(
			"/internal/ip/get",
			false,
			onCallback
		);
	};
})(space);