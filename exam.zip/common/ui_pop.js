(function(g) {
	g.info = function(msg) {
		g.el("div", "message")
			.$parent()
			.$append(
				g.el("span", "panel")
				.$append(g.icon("icon-info")
					.$style({
						color: "Green"
					}))
				.$append(g.el("span").$text(msg))
			)
			.$timeout(2000);
	};

	g.error = function(msg) {
		g.el("div", "message")
			.$parent()
			.$append(
				g.el("span", "panel")
				.$append(g.icon("icon-blocked")
					.$style({
						color: "Red"
					}))
				.$append(g.el("span")
					.$text(msg))
			)
			.$timeout(2000);
	};

	// Show a dialog.
	g.modal = function(obj, size, onOK, cancelable, closable) {
		var p = g.el("div", "mask").$parent();

		var q = g.el("div").$parent().$style({
				position: "fixed",
				top: "0px",
				button: "0px",
				left: "0px",
				right: "0px"
			})
			.$append(g.el("div", "modal")
				.$style({
					width: (function() {
						switch (size) {
							case g.TINY:
								return "20%";
							case g.SMALL:
								return "30%";
							case g.NORMAL:
							default:
								return "50%";
							case g.BIG:
								return "70%";
							case g.HUGE:
								return "90%";
						}
					})()
				})
				.$append(obj)
				.$append(
					cancelable ? g.button((g.en ? "Cancel" : "取消"), function() {
						q.$remove();
						p.$remove();
					}) : null)
				.$append(g.button((g.en ? "OK" : "确定"), function(evt) {
					if (typeof onOK === "function") {
						if (onOK() === true) {
							q.$remove();
							p.$remove();
						}
					} else {
						q.$remove();
						p.$remove();
					}
				}))
				.$append(
					closable ? (g.icon("icon-cross")
						.$bind({
							onclick: function(evt) {
								q.$remove();
								p.$remove();
							}
						})
						.$style({
							position: "absolute",
							fontSize: "0.625em",
							top: "5px",
							right: "5px"
						})
					) : null
				));
	};

	g.remove();
})(ui);