(function(g) {

	g.loginAsGaodunStudent = function(password, onCallback) {
		g.sender.clearSession();
		g.sender.invoke(
			"/gaodun/pass?password=" + encodeURIComponent(password),
			true,
			function(resp) {
				// window.alert("onLoginAsGaodunStudent");
				if (resp.status === 0) {
					g.data.me.id = resp.result.id;
					g.data.me.nickname = resp.result.nickname;
					g.data.me.role = "STUDENT";
					g.data.currentClass = resp.result.class;

					g.sender.setID(g.data.me.id);

					g.queryClass(
						function(resp) {
							if (resp.status === 0) {
								g.data.classes = resp.result.classList;
								g.queryMeeting(g.data.currentClass, onCallback);
							} else {
								if (g.isFunction(onCallback)) {
									onCallback(resp);
								}
							}
						},
						0);
				} else {
					if (g.isFunction(onCallback)) {
						onCallback(resp);
					}
				}
			}
		);
	};

	g.registerExperienceStudent = function(classID, teacherID, password, phone, verification, onCallback) {
		g.sender.clearSession();
		var params = "?class=" + classID + "&phone=" + phone + "&verification=" + verification;
		if (teacherID > 0) {
			params += "&teacher=" + teacherID;
		} else {
			params += "&password=" + password;
		}
		g.sender.invoke(
			"/user/experience/register" + params,
			true,
			function(resp) {
				if (resp.status === 0) {
					g.data.me.id = resp.result.id;
					g.data.me.nickname = resp.result.nickname;
					g.data.me.role = "STUDENT";

					g.sender.setID(g.data.me.id);

					g.queryClass(
						function(resp) {
							if (resp.status === 0) {
								g.data.classes = resp.result.classList;

								if (g.data.classes.length > 0) {
									g.data.currentClass = g.data.classes[0].id;
									g.queryMeeting(g.data.currentClass, onCallback);
								}
							} else {
								if (g.isFunction(onCallback)) {
									onCallback(resp);
								}
							}
						},
						0
					);
				} else {
					if (g.isFunction(onCallback)) {
						onCallback(resp);
					}
				}
			}
		);
	};

	g.loginAsExperienceStudent = function(password, onCallback) {
		g.sender.clearSession();
		g.sender.invoke(
			"/user/experience?password=" + encodeURIComponent(password),
			true,
			function(resp) {
				if (resp.status === 0) {
					g.data.me.id = resp.result.id;
					g.data.me.nickname = resp.result.nickname;
					g.data.me.role = "STUDENT";

					g.sender.setID(g.data.me.id);

					g.queryClass(
						function(resp) {
							if (resp.status === 0) {
								g.data.classes = resp.result.classList;

								if (g.data.classes.length > 0) {
									g.data.currentClass = g.data.classes[0].id;
									g.queryMeeting(g.data.currentClass, onCallback);
								}
							} else {
								if (g.isFunction(onCallback)) {
									onCallback(resp);
								}
							}
						},
						0
					);
				} else {
					if (g.isFunction(onCallback)) {
						onCallback(resp);
					}
				}
			}
		);
	};

	g.getClassBrief = function(onCallback) {
		g.sender.invoke(
			"/gaodun/class/query",
			true,
			onCallback
		);
	};
	g.getClassBriefViaCookie = function(session, onCallback) {
		g.sender.invoke(
			"/gaodun/class/query?session=" + session,
			false,
			onCallback
		);
	};

	g.askForLeave = function(meetingID, onCallback) {
		if (!g.isStudent()) {
			return;
		}
		g.sender.invoke(
			"/meeting/leave?meeting=" + meetingID + "&cancel=0",
			true,
			onCallback
		);
	};
	g.cancelLeave = function(meetingID, onCallback) {
		if (!g.isStudent()) {
			return;
		}
		g.sender.invoke(
			"/meeting/leave?meeting=" + meetingID + "&cancel=1",
			true,
			onCallback
		);
	};

	g.finishCourseware = function(meetingID, coursewareID, onCallback) {
		if (!g.isStudent()) {
			return;
		}
		g.sender.invoke(
			"/meeting/courseware/finish?meeting=" + meetingID + "&courseware=" + encodeURIComponent(coursewareID),
			true,
			onCallback
		);
	};
	g.finishVideo = function(meetingID, videoID, onCallback) {
		if (!g.isStudent()) {
			return;
		}
		g.sender.invoke(
			"/meeting/video/finish?meeting=" + meetingID + "&video=" + encodeURIComponent(videoID),
			true,
			onCallback
		);
	};
	g.finishReplay = function(meetingID, onCallback) {
		if (!g.isStudent()) {
			return;
		}
		g.sender.invoke(
			"/meeting/replay/finish?meeting=" + meetingID,
			true,
			onCallback
		);
	};
	g.answerExam = function(meetingID, examID, answer, onCallback) {
		if (!g.isStudent()) {
			return;
		}
		g.sender.invoke(
			"/meeting/exam/answer?meeting=" + meetingID + "&exam=" + examID + "&answer=" + answer,
			true,
			onCallback
		);
	};
	g.answerExamQuestion = function(meetingID, examID, questionID, answer, onCallback) {
		if (!g.isStudent()) {
			return;
		}
		g.sender.invoke(
			"/meeting/exam/question/answer?meeting=" + meetingID + "&exam=" + examID + "&question=" + questionID + "&answer=" + encodeURIComponent(answer),
			true,
			onCallback
		);
	};

	g.queryMyProgress = function(classID, onCallback) {
		if (!g.isStudent()) {
			return;
		}
		g.sender.invoke(
			"/class/progress/query?class=" + classID,
			true,
			function(resp) {
				if (resp.status === 0) {
					g.data.myProgress = resp.result.progress;
					g.saveData();
				}

				if (g.isFunction(onCallback)) {
					onCallback(resp);
				}
			}
		);
	};

	g.getTypedNote = function(noteType, key, onCallback) {
		if (!g.isStudent()) {
			return;
		}
		g.sender.invoke(
			"/note/get?type=" + noteType + "&key=" + key,
			true,
			onCallback
		);
	};

	g.scoreMeeting = function(meetingID, scores, feedback, onCallback) {
		if (!g.isStudent()) {
			return;
		}
		g.sender.invoke(
			"/meeting/score?meeting=" + meetingID + "&score=" + encodeURIComponent(scores) + "&feedback=" + encodeURIComponent(feedback),
			true,
			onCallback
		);
	};

})(space);