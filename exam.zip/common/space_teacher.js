(function(g) {

	//----------------------------------------------------
	// User-related methods.

	g.markStudent = function(name, mark, studentID, classID, onCallback) {
		g.sender.invoke(
			"/class/student/remark?name=" + encodeURIComponent(name) + "&remark=" + encodeURIComponent(mark) + "&student=" + studentID + "&class=" + classID,
			true,
			onCallback
		);
	};

	g.inviteStudent = function(classID, userName, onCallback) {
		g.sender.invoke(
			"/class/invite?class=" + classID + "&name=" + encodeURIComponent(userName),
			true,
			onCallback
		);
	};

	g.scanStudent = function(meetingID, studentID, studentToken, onCallback, onNetError) {
		g.sender.invoke(
			"/user/scan?meeting=" + meetingID + "&user=" + studentID + "&password=" + studentToken,
			true,
			onCallback,
			onNetError
		);
	};

	g.queryInvitationTokenByClass = function(classID, isTeacher, onCallback) {
		var params = "?class=" + classID;
		if (isTeacher) {
			params += "&isTeacher=1";
		}
		g.sender.invoke(
			"/class/invitation/query" + params,
			true,
			onCallback
		);
	};

	g.queryExperienceStudentByClass = function(classID, isTeacher, onCallback) {
		var params = "?class=" + classID;
		if (isTeacher) {
			params += "&isTeacher=1";
		}
		g.sender.invoke(
			"/class/experience/query" + params,
			true,
			onCallback
		);
	};

	//----------------------------------------------------
	// Meeting-related methods.

	var onMeetingCallback = function(onCallback) {
		return function(resp) {
			if ((resp.status === 0) && (g.data.currentClass > 0)) {
				g.queryMeeting(g.data.currentClass, onCallback);
			} else {
				if (g.isFunction(onCallback)) {
					onCallback(resp);
				}
			}
		};
	};

	g.createMeeting = function(classID, section, meetingName, startTime, duration, type, data, onCallback) {
		g.sender.invoke(
			"/class/meeting/add?class=" + classID + "&section=" + section + "&name=" + encodeURIComponent(meetingName) + "&startTime=" + startTime + "&duration=" + duration + "&type=" + type + "&data=" + encodeURIComponent(data),
			true,
			onMeetingCallback(onCallback)
		);
	};
	g.deleteMeeting = function(classID, meetingID, permanent, onCallback) {
		g.sender.invoke(
			"/class/meeting/delete?class=" + classID + "&meeting=" + meetingID + "&permanent=" + (permanent === true ? "1" : "0"),
			true,
			onMeetingCallback(onCallback)
		);
	};
	g.endMeeting = function(classID, meetingID, onCallback) {
		g.sender.invoke(
			"/class/meeting/end?class=" + classID + "&meeting=" + meetingID,
			true,
			onMeetingCallback(onCallback)
		);
	};
	g.cloneMeeting = function(meetingID, destClassID, onCallback) {
		g.sender.invoke(
			"/class/meeting/copy?meeting=" + meetingID + "&class=" + destClassID,
			true,
			onCallback
		);
	};
	g.changeMeetingName = function(meetingID, meetingName, onCallback) {
		g.sender.invoke(
			"/meeting/name/change?meeting=" + meetingID + "&name=" + encodeURIComponent(meetingName),
			true,
			onMeetingCallback(onCallback)
		);
	};
	g.changeMeetingTime = function(meetingID, startTime, duration, onCallback) {
		g.sender.invoke(
			"/meeting/time/change?meeting=" + meetingID + "&startTime=" + startTime + "&duration=" + duration,
			true,
			onMeetingCallback(onCallback)
		);
	};
	g.changeMeetingType = function(meetingID, meetingType, data, onCallback) {
		g.sender.invoke(
			"/meeting/type/change?meeting=" + meetingID + "&type=" + meetingType + "&data=" + encodeURIComponent(data),
			true,
			onMeetingCallback(onCallback)
		);
	};
	g.changeMeetingSection = function(meetingID, section, onCallback) {
		g.sender.invoke(
			"/meeting/section/change?meeting=" + meetingID + "&section=" + section,
			true,
			onMeetingCallback(onCallback)
		);
	};

	//----------------------------------------------------
	// Resource-related methods.

	g.addCourseware = function(meetingID, coursewareName, file, coursewareID, preparation, necessary, onCallback, onProgress) {
		var params = "?meeting=" + meetingID + "&name=" + encodeURIComponent(coursewareName);
		params += (g.Methods.isValid(preparation) ? ("&preparation=" + preparation) : "");
		params += (g.Methods.isValid(necessary) ? ("&necessary=" + necessary) : "");

		if (coursewareID) {
			g.sender.invoke(
				"/meeting/courseware/add" + params + "&courseware=" + encodeURIComponent(coursewareID),
				true,
				onMeetingCallback(onCallback)
			);
		} else if (file) {
			g.sender.upload(
				"/meeting/courseware/add" + params,
				file,
				onMeetingCallback(onCallback),
				null,
				null,
				onProgress
			);
		}
	};
	g.deleteCourseware = function(meetingID, coursewareID, onCallback) {
		g.sender.invoke(
			"/meeting/courseware/delete?meeting=" + meetingID + "&courseware=" + coursewareID,
			true,
			onMeetingCallback(onCallback)
		);
	};
	g.addVideo = function(meetingID, videoID, videoName, preparation, necessary, onCallback) {
		var params = "?meeting=" + meetingID + "&video=" + encodeURIComponent(videoID) + "&name=" + encodeURIComponent(videoName);
		params += (preparation ? ("&preparation=" + preparation) : "");
		params += (necessary ? ("&necessary=" + necessary) : "");

		g.sender.invoke(
			"/meeting/video/add" + params,
			true,
			onMeetingCallback(onCallback)
		);
	};
	g.deleteVideo = function(meetingID, videoID, onCallback) {
		g.sender.invoke(
			"/meeting/video/delete?meeting=" + meetingID + "&video=" + encodeURIComponent(videoID),
			true,
			onMeetingCallback(onCallback)
		);
	};
	g.addReplay = function(meetingID, videoID, onCallback) {
		g.sender.invoke(
			"/meeting/replay/add?meeting=" + meetingID + "&video=" + encodeURIComponent(videoID),
			true,
			onMeetingCallback(onCallback)
		);
	};
	g.deleteReplay = function(meetingID, videoID, onCallback) {
		g.sender.invoke(
			"/meeting/replay/delete?meeting=" + meetingID + "&video=" + encodeURIComponent(videoID),
			true,
			onMeetingCallback(onCallback)
		);
	};
	g.addExam = function(meetingID, examID, gaodunExamID, examName, startTime, duration, preparation, necessary, onCallback) {
		var params = "?meeting=" + meetingID + "&name=" + encodeURIComponent(examName) + "&startTime=" + startTime + "&duration=" + duration;
		params += (examID ? ("&exam=" + examID) : "");
		params += (gaodunExamID ? ("&gaodunExamID=" + gaodunExamID) : "");
		params += (preparation ? ("&preparation=" + preparation) : "");
		params += (necessary ? ("&necessary=" + necessary) : "");

		g.sender.invoke(
			"/meeting/exam/add" + params,
			true,
			onMeetingCallback(onCallback)
		);
	};
	g.resyncExam = function(meetingID, examID, onCallback) {
		g.sender.invoke(
			"/meeting/exam/resync?meeting=" + meetingID + "&exam=" + examID,
			true,
			onCallback
		);
	};
	g.deleteExam = function(meetingID, examID, onCallback) {
		g.sender.invoke(
			"/meeting/exam/delete?meeting=" + meetingID + "&exam=" + examID,
			true,
			onMeetingCallback(onCallback)
		);
	};

	g.getExamAnswers = function(meetingID, examID, onCallback) {
		g.sender.invoke(
			"/meeting/exam/answer/get?meeting=" + meetingID + "&exam=" + examID,
			true,
			onCallback
		);
	};

	//----------------------------------------------------
	// Progress-related methods.

	g.queryProgressByClass = function(classID, userID, onCallback) {
		var params = "?class=" + classID;
		params += (userID ? "&user=" + userID : "");
		g.sender.invoke(
			"/class/progress/query" + params,
			true,
			onCallback
		);
	};

	g.getFeedback = function(meetingID, onCallback) {
		g.sender.invoke(
			"/meeting/feedback/get?meeting=" + meetingID,
			true,
			onCallback
		);
	};

	g.downloadFeedback = function(classID, meetingID, onCallback) {
		// Get students' names beforehand.
		g.queryStudentByClass(
			classID,
			function(resp) {
				if (resp.status === 0) {
					// Get meeting progresses.
					g.queryProgressByMeeting(
						meetingID,
						function(resp) {
							if (resp.status === 0) {
								var meetingProgresses = resp.result.progress;

								// Get meeting feedbacks.
								g.getFeedback(
									meetingID,
									function(resp) {
										if (resp.status === 0) {
											var feedbacks = resp.result.feedback;

											var s = "";
											for (var i = 0; i < meetingProgresses.length; i++) {
												// Nickname.
												var nickname = space.data.students[meetingProgresses[i].userID].nickname;
												nickname = nickname.replace(/\"/g, "\"\"");
												
												var gaodunStudentID = "";
												if (space.data.students[meetingProgresses[i].userID].gaodunStudentID > 0) {
													gaodunStudentID = space.data.students[meetingProgresses[i].userID].gaodunStudentID;
												}

												var scores = "";
												if (meetingProgresses[i].score.length > 0) {
													scores = "\""+meetingProgresses[i].score+"\"";
												}

												var feedback = "";
												if (feedbacks[meetingProgresses[i].userID]) {
													feedback = decodeURIComponent(feedbacks[meetingProgresses[i].userID].feedback);
													feedback = feedback.replace(/\"/g, "\"\"");
													if (feedback.indexOf(",") >= 0) {
														feedback = "\"" + feedback + "\"";
													}
												}

												s += nickname + "," +
													gaodunStudentID + "," +
													scores + "," +
													feedback + "\r\n";
											}
											console.log(s);
										} else {
											if (g.isFunction(onCallback)) {
												onCallback(resp);
											}
										}
									}
								);
							} else {
								if (g.isFunction(onCallback)) {
									onCallback(resp);
								}
							}
						}
					);
				} else {
					if (g.isFunction(onCallback)) {
						onCallback(resp);
					}
				}
			}
		);
	};

})(space);