(function(g) {
	//----------------------------------------------------
	// Class-related methods.

	var onClassCallback = function(onCallback) {
		return function(resp) {
			if (resp.status === 0) {
				g.queryClass(onCallback);
			} else {
				if (g.isFunction(onCallback)) {
					onCallback(resp);
				}
			}
		};
	};

	g.createClass = function(className, gaodunCourseID, platformID, platformData, groupID, onCallback) {
		var params = "?name=" + encodeURIComponent(className);
		params += (g.Methods.isValid(gaodunCourseID) ? ("&gaodunCourseID=" + gaodunCourseID) : "");
		params += (g.Methods.isValid(platformID) ? ("&platformID=" + platformID) : "");
		params += (g.Methods.isValid(platformData) ? ("&platformData=" + encodeURIComponent(platformData)) : "");
		params += (g.Methods.isValid(groupID) ? ("&group=" + groupID) : "");
		g.sender.invoke(
			"/class/add" + params,
			true,
			onClassCallback(onCallback)
		);
	};
	g.importGaodunCourse = function(name, gaodunCourseID, onCallback) {
		var params = "?name=" + encodeURIComponent(name) + "&gaodunCourseID=" + gaodunCourseID;
		if (g.isSystem()) {
			params += "&group=" + g.data.currentGroup;
		}
		g.sender.invoke(
			"/class/import" + params,
			true,
			onClassCallback(onCallback)
		);
	};
	g.getGaodunCourse = function(courseID, onCallback) {
		g.sender.invoke(
			"/gaodun/courseware/get?courseware=" + courseID,
			true,
			onCallback
		);
	};
	g.modifyClass = function(classID, className, gaodunCourseID, platformID, platformData, onCallback) {
		var params = "?class=" + classID + "&name=" + encodeURIComponent(className);
		params += (gaodunCourseID ? ("&gaodunCourseID=" + gaodunCourseID) : "");
		params += (platformID ? ("&platformID=" + platformID) : "");
		params += (platformData ? ("&platformData=" + encodeURIComponent(platformData)) : "");
		g.sender.invoke(
			"/class/change" + params,
			true,
			onClassCallback(onCallback)
		);
	};
	g.cloneClass = function(classID, className, platformID, platformData, onCallback) {
		var params = "?class=" + classID + "&name=" + encodeURIComponent(className);
		params += (platformID ? ("&platformID=" + platformID) : "");
		params += (platformData ? ("&platformData=" + encodeURIComponent(platformData)) : "");
		g.sender.invoke(
			"/class/clone" + params,
			true,
			onClassCallback(onCallback)
		);
	};
	g.endClass = function(classID, onCallback) {
		g.sender.invoke(
			"/class/end?class=" + classID,
			true,
			onClassCallback(onCallback)
		);
	};
	g.deleteClass = function(classID, onCallback) {
		g.sender.invoke(
			"/class/delete?class=" + classID,
			true,
			onClassCallback(onCallback)
		);
	};
	g.publishClass = function(classID, onCallback) {
		g.sender.invoke(
			"/class/publish?class=" + classID,
			true,
			onCallback
		);
	};
	g.packageClass = function(classID, onCallback) {
		g.sender.invoke(
			"/class/package?class=" + classID,
			true,
			onCallback
		);
	};
	g.setClassAlly = function(classID, ally, onCallback) {
		g.sender.invoke(
			"/class/ally/set?class=" + classID + "&ally=" + ally,
			true,
			onCallback
		);
	};

	g.generateInvitationTokenForClass = function(classID, endTime, duration, teacherID, channel, size, onCallback) {
		var params = "?class=" + classID + "&endTime=" + endTime + "&duration=" + duration;
		if (channel) {
			params += "&channel=" + encodeURIComponent(channel) + "&size=" + size;
		} else {
			params += "&teacher=" + teacherID;
		}
		
		g.sender.invoke(
			"/class/invitation/generate" + params,
			true,
			onCallback
		);
	};

	//----------------------------------------------------
	// Teacher-related methods.

	var onTeacherCallback = function(onCallback) {
		return function(resp) {
			if (resp.status === 0) {
				g.queryTeacherByClass(g.currentClass, onCallback);
			} else {
				if (g.isFunction(onCallback)) {
					onCallback(resp);
				}
			}
		};
	};

	g.addTeacher = function(classID, userID, onCallback) {
		g.sender.invoke(
			"/class/teacher/add?class=" + classID + "&teacher=" + userID,
			true,
			onTeacherCallback(onCallback)
		);
	};
	g.deleteTeacher = function(classID, userID, onCallback) {
		g.sender.invoke(
			"/class/teacher/delete?class=" + classID + "&teacher=" + userID,
			true,
			onTeacherCallback(onCallback)
		);
	};
	g.queryTeacherByName = function(name, onCallback) {
		g.sender.invoke(
			"/user/query?name=" + encodeURIComponent(name) + "&group=3",
			true,
			onCallback
		);
	};

	//----------------------------------------------------
	// Student-related methods.

	var onStudentCallback = function(onCallback) {
		return function(resp) {
			if (resp.status === 0) {
				g.queryStudentByClass(g.data.currentClass, onCallback);
			} else {
				if (g.isFunction(onCallback)) {
					onCallback(resp);
				}
			}
		};
	};

	g.addStudent = function(classID, userID, onCallback) {
		g.sender.invoke(
			"/class/student/add?class=" + classID + "&student=" + userID,
			true,
			onStudentCallback(onCallback)
		);
	};
	g.addGaodunStudent = function(classID, gaodunStudentID, onCallback) {
		g.sender.invoke(
			"/class/gaodunStudent/add?class=" + classID + "&gaodunStudentID=" + gaodunStudentID,
			true,
			onStudentCallback(onCallback)
		);
	};
	g.deleteStudent = function(classID, userID, onCallback) {
		g.sender.invoke(
			"/class/student/delete?class=" + classID + "&student=" + userID,
			true,
			onStudentCallback(onCallback)
		);
	};
	g.queryStudentByName = function(name, onCallback) {
		g.sender.invoke(
			"/user/query?name=" + encodeURIComponent(name) + "&group=2",
			true,
			onCallback
		);
	};

	//----------------------------------------------------
	// Meeting-related methods.

	g.createMeetingConfig = function() {
		var instance = {
			platform: {
				roomId: "",
				userId: ""
			},
			ui: {
				chat: 0,
				question: 1,
				drawPanel: 1,
				thumbsUp: 0,
				document: 1
			},
			live: {
				liveDesc: "",
				teacherDesc: "",
				onlineBias: 1000
			},
			goods: [],
			advert: {
				img: "",
				link: ""
			}
		};

		instance.setPlatform = function(roomId, userId) {
			instance.platform.roomId = roomId;
			instance.platform.userId = userId;
		};

		instance.addGood = function(img, title, price, link) {
			instance.goods.push({
				img: img,
				title: title,
				price: price,
				link: link
			});
		};
		
		instance.setAdvertisement = function(img, link) {
			instance.advert.img = img;
			instance.advert.link = link;
		};

		return instance;
	};
	g.setMeetingConfig = function(meetingID, cfg, onCallback) {
		var s = LZString.compressToBase64(JSON.stringify(cfg));
		g.sender.invoke(
			"/meeting/config/set?meeting=" + meetingID + "&config=" + encodeURIComponent(s),
			true,
			onCallback
		);
	};

})(space);