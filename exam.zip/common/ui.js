var ui = ui || (function() {
	var g = {
		en: (navigator.language.indexOf("zh") === 0 ? false : true),

		TINY: 0,
		SMALL: 1,
		NORMAL: 2,
		BIG: 3,
		HUGE: 4
	};

	// Define a JQuery-like method.
	g.$ = function(id) {
		if ((typeof id !== "string") || (id.length === 0)) {
			return null;
		}

		if (id[0] !== '.') {
			return document.getElementById(id);
		}

		return document.getElementsByClassName(id.substr(1));
	};

	g.meta = function() {
		var ratio = 1;
		if (navigator.appVersion.match(/iphone/gi)) {
			ratio = Math.floor(window.devicePixelRatio);
		}

		// var w = document.documentElement.getBoundingClientRect().width;
		var w = screen.width;
		if ((w / ratio) > 540) {
			w = 540 * ratio;
		}
		w = Math.floor(w * ratio / 10);

		var scale = (1 / ratio).toFixed(2).toString();

		document.documentElement.setAttribute("data-dpr", ratio);
		document.documentElement.setAttribute("style", "font-size: " + w + "px;");

		var meta = document.createElement("meta");
		meta.setAttribute("name", "viewport");
		meta.setAttribute("content", "initial-scale=" + scale + ", maximum-scale=" + scale + ", minimum-scale=" + scale + ", user-scalable=no");
		document.documentElement.firstElementChild.appendChild(meta);
	};

	g.empty = function() {
		document.body.bgColor = "#FFFFFF";
		document.body.innerHTML = "";
	};

	g.href = function(url, isBlank) {
		if (!url || url.length === 0) {
			return;
		}

		if (url.indexOf("//") === 0 || url.indexOf("http") === 0) {
			var a = g.el("a");
			a.href = url;
			a.target = (isBlank === true ? "_blank" : "_self");
			a.click();
		} else {
			window.location.href = "#" + url;
		}
	};

	// Create an document element.
	g.el = function(tag, klass, onclick) {
		var r = document.createElement(tag);

		// Set its style via class and specific features.
		if (typeof klass === "string") {
			r.className = klass;
		}
		// Bind events.
		if (typeof onclick === "function") {
			r.onclick = onclick;
			r.style.cursor = "pointer";
		}

		r.$id = function(s) {
			if (typeof s === "string") {
				r.id = s;
			}
			return r;
		};
		r.$name = function(s) {
			if (typeof s === "string") {
				r.name = s;
			}
			return r;
		};
		r.$value = function(v) {
			r.value = v;
			return r;
		};
		r.$text = function(s) {
			if (typeof s === "string") {
				r.innerText = s;
			}
			return r;
		};
		r.$class = function(s) {
			if (typeof s === "string") {
				r.className = s;
			}
			return r;
		};
		r.$style = function(styles) {
			if (styles && (typeof styles === "object")) {
				for (var key in styles) {
					if (typeof styles[key] === "string") {
						r.style[key] = styles[key];
					}
				}
			}
			return r;
		};
		r.$bind = function(events) {
			if (events && (typeof events === "object")) {
				for (var key in events) {
					if (typeof events[key] === "function") {
						r[key] = events[key];
					}
				}
			}
			if (r.onclick) {
				r.style.cursor = "pointer";
			}
			return r;
		};
		r.$parent = function(obj) {
			if (obj && (typeof obj === "object")) {
				obj.appendChild(r);
			} else {
				document.body.appendChild(r);
			}
			return r;
		};
		r.$append = function(obj) {
			if (obj && (typeof obj === "object")) {
				r.appendChild(obj);
			}
			return r;
		};
		r.$empty = function() {
			r.innerHTML = "";
			return r;
		};
		r.$remove = function() {
			var p = r.parentNode;
			if (p && (typeof p === "object")) {
				p.removeChild(r);
			}
			return r;
		};
		r.$timeout = function(ms) {
			setTimeout(
				function() {
					r.$remove();
				},
				ms);
			return r;
		};
		return r;
	};

	//----------------------------------------------------
	// Common.

	g.i = function() {
		return g.el("i");
	};

	g.div = function(klass, onclick) {
		return g.el("div", klass, onclick);
	};
	g.span = function(text, onclick) {
		return g.el("span", onclick).$text(text);
	};

	g.h = function(n, title) {
		return g.el("h" + n).$text(title);
	};

	g.hr = function() {
		return g.el("hr");
	};

	g.img = function(s) {
		var r = g.el("img");
		if (s && typeof s === "string") {
			r.src = s;
		}
		return r;
	};

	g.icon = function(klass) {
		var r = g.el("span", klass).$style({
			margin: "0px 3px 0px 3px"
		});

		return r;
	};

	//----------------------------------------------------
	// Form-related.

	g.button = function(title, onclick, klass) {
		return g.el("button", klass, onclick).$text(title);
	};

	g.input = function(type, actions) {
		var r = g.el("input").$bind(actions);
		r.type = type;

		r.$size = function(size) {
			r.size = size;
			return r;
		};

		return r;
	};

	//----------------------------------------------------
	// Table-related.

	g.table = function() {
		return g.el("table");
	};
	g.thead = function() {
		var r = g.el("thead");
		r.$span = function(n) {
			r.rowSpan = n;
			return r;
		};
		return r;
	};
	g.th = function(s, align) {
		var r = g.el("th").$text(s);

		if (align && typeof align === "string") {
			r.$style({
				textAlign: align
			});
		}

		r.$span = function(n) {
			r.colSpan = n;
			return r;
		};
		return r;
	};
	g.tr = function() {
		var r = g.el("tr");
		r.$span = function(n) {
			r.rowSpan = n;
			return r;
		};
		return r;
	};
	g.td = function(s, align) {
		var r = g.el("td").$text(s);

		if (align && typeof align === "string") {
			r.$style({
				textAlign: align
			});
		}

		r.$span = function(n) {
			r.colSpan = n;
			return r;
		};
		r.$rowSpan = function(n) {
			r.rowSpan = n;
			return r;
		};
		return r;
	};

	g.progress = function(value, max) {
		var r = g.el("div");

		r.$append(g.span);

		return r;
	};

	//----------------------------------------------------
	// Others.

	g.remove = function() {
		var arr = document.getElementsByTagName("script");
		var c = arr[arr.length - 1];
		var p = c.parentNode;
		if (p && (typeof p === "object")) {
			p.removeChild(c);
		}
	};

	g.remove();
	return g;
})();