(function(g) {
	//----------------------------------------------------
	// Navigation.

	g.navi = function() {
		var r = g.el("div", "navi");

		r.$menu = function(title, onclick) {
			var m = g.el("div", "menu").$parent(r);

			m._title = g.el("span", null, onclick).$parent(m).$text(title);

			m.$item = function(title, onclick) {
				if (!m._items) {
					// Add an icon denoting here is a list.
					// g.img(g.i.dropdown).$parent(m);
					g.icon("icon-circle-down").$parent(m);

					// Create a container for those menu items.
					m._items = g.el("div", "panel").$parent(m).$style({
						display: "none"
						// visibility: "hidden"
					});

					// Set up the callback of click event of the menu itself.
					m.onclick = function(evt) {
						m._items.style.display = (m._items.style.display === "none") ? "block" : "none";
						// m._items.style.visibility = (m._items.style.visibility === "hidden") ? "visible" : "hidden";
					};
					// m.onmouseover = function() {m._items.style.visibility = "visible";};
					// m.onmouseout = function() {m._items.style.visibility = "hidden";};
					m.style.cursor = "pointer";

					// Hide the container automatically.
					m.tabIndex = 1;
					m.onblur = function(evt) {
						m._items.style.display = "none";
						// m._items.style.visibility = "hidden";
					};
				}

				g.el("span", null, onclick).$parent(m._items).$text(title);

				return m;
			};
			return m;
		};
		return r;
	};

	//----------------------------------------------------
	// Drop-down.

	g.dropdown = function(title) {
		var r = g.el("div", "dropdown");

		r.$item = function(title, onclick) {
			if (!r._items) {
				// g.img(g.i.dropdown).$parent(r);

				r._items = g.el("div", "panel").$parent(r).$style({
					display: "none"
				});

				r.onclick = function(evt) {
					r._items.style.display = (r._items.style.display === "none") ? "block" : "none";
				}
				r.style.cursor = "pointer";

				r.tabIndex = 1;
				r.onblur = function(evt) {
					r._items.style.display = "none";
				};
			}

			g.el("span", null, (function(s) {
				return function(evt) {
					r.$text(s);
					if (onclick && typeof onclick === "function") {
						onclick(evt);
					}
				};
			})(title)).$parent(r._items).$text(title);

			return r;
		};
		return r;
	};

	g.remove();
})(ui);