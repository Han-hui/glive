var RequestSender = {
	createNew: function(apiPrefix, useLocalStorage, app) {
		var instance = {
			apiPrefix: apiPrefix,
			q: [],
			cache: {},
			isWorking: false,
			onHttpError: null,
			useLocalStorage: useLocalStorage,
			app: app
		};

		instance.invoke = function(url, withSession, onSuccess, onError) {
			instance.q.push({
				json: true,
				method: "POST",
				url: instance.apiPrefix + url,
				withSession: withSession,
				data: null,
				onSuccess: onSuccess,
				onError: (typeof onError === "function" ? onError : instance.onHttpError),
				onOpened: null,
				onProgress: null
			});

			startToWork();
		};

		instance.upload = function(url, file, onSuccess, onError, onOpened, onProgress) {
			var fileForm = new FormData();
			fileForm.append("file", file);

			instance.q.push({
				json: true,
				method: "POST",
				url: instance.apiPrefix + url,
				withSession: true,
				data: fileForm,
				onSuccess: onSuccess,
				onError: onError,
				onOpened: onOpened,
				onProgress: onProgress
			});

			startToWork();
		};

		instance.download = function(url, onSuccess, onError) {
			instance.q.push({
				json: false,
				method: "GET",
				url: url,
				withSession: false,
				data: null,
				onSuccess: onSuccess,
				onError: onError,
				onOpened: null,
				onProgress: null
			});

			startToWork();
		};

		instance.setHTTPError = function(onError) {
			instance.onHttpError = onError;
		};

		var setItem = function(name, value) {
			instance.cache[name] = value;

			if (instance.useLocalStorage) {
				localStorage.setItem(name, value);
			}
		};
		var getItem = function(name) {
			return (instance.useLocalStorage ? localStorage.getItem(name) : instance.cache[name]);
		};

		instance.setID = function(id) {
			setItem("id", id);
		};
		instance.getID = function() {
			return getItem("id");
		};
		instance.setToken = function(token) {
			setItem("token", token);
		};
		instance.getToken = function() {
			return getItem("token");
		};
		instance.setTime = function(time) {
			setItem("time", time);
		};
		instance.getTime = function() {
			return getItem("time");
		};

		instance.clearSession = function() {
			instance.setID("");
			instance.setToken("");
		};

		instance.saveTokenToNative = function() {
			if (instance.app === 0) {
				return;
			}
			if (!Native || !Native.notifyCallMethod) {
				return;
			}

			var s = JSON.stringify({
				id: instance.getID(),
				token: instance.getToken()
			});
			Native.notifyCallMethod(
				"saveFile", {
					name: "glive",
					data: s
				},
				function(e) {;
				}
			);
		};
		instance.loadTokenFromNative = function(onCallback) {
			if (!Native || !Native.notifyCallMethod) {
				return;
			}

			Native.notifyCallMethod(
				"getFile", {
					name: "glive"
				},
				function(result) {
					// window.alert(JSON.stringify(result));
					if (result.data.length > 0) {
						var obj = JSON.parse(result.data);

						instance.setID(obj.id);
						instance.setToken(obj.token);
					}

					if (typeof onCallback === "function") {
						onCallback(result.data.length > 0 ? true : false);
					}
				}
			);
		};

		instance.saveAnswerToNative = function(id, answer) {
            if (instance.app === 0) {
                return;
            }
            if (!Native || !Native.notifyCallMethod) {
                return;
            }

            var s = JSON.stringify({
                id: id,
                answer: answer
            });
            Native.notifyCallMethod(
                "saveFile", {
                    name: "a",
                    data: s
                },
                function(e) {
                }
            );
        };
        instance.loadAnswerFromNative = function(id, onCallback) {
            if (!Native || !Native.notifyCallMethod) {
                return;
            }

            Native.notifyCallMethod(
                "getFile", {
                    name: "a"
                },
                function(result) {
                	// window.alert(result.data);
                    if (result.data.length > 0) {
                        var obj = JSON.parse(result.data);

                        var examId = obj.id;
                        // if(parseInt(examId) === parseInt(id)){
                        if (obj.id === id) {
                        	// window.alert("a");
                            // window.alert(JSON.stringify(obj.answer));
                            
                            if (localStorage) {
                            	localStorage.setItem("userAnswer", JSON.stringify(obj.answer));
                            }
                            // window.alert("b");
                        }
                    }

                    if (typeof onCallback === "function") {
                        onCallback();
                    }
                }
            );
        };

		var startToWork = function() {
			if (instance.q.length === 0) {
				return;
			}

			// Get a request for the queue.
			var r = instance.q[0];

			if (r.withSession === true) {
				if (instance.isWorking === true) {
					return;
				} else {
					instance.isWorking = true;
				}
			}

			// Remove this request from the queue.
			instance.q.splice(0, 1);

			// Send it.
			request(
				r.method,
				r.url,
				r.withSession,
				r.data,
				function(xhr) {
					if (typeof r.onSuccess === "function") {
						if (r.json === true) {
							var obj = eval("(" + xhr.responseText + ")");
							r.onSuccess(obj);
						} else {
							r.onSuccess(xhr);
						}
					}

					// Process next request, if it exists.
					if (r.withSession === true) {
						instance.isWorking = false;
					}
					startToWork();
				},
				function(n) {
					if (typeof r.onError === "function") {
						r.onError(n);
					}

					// Process next request, if it exists.
					if (r.withSession === true) {
						instance.isWorking = false;
					}
					startToWork();
				},
				r.onOpened,
				r.onProgress
			);
		};

		var request = function(method, url, withSession, data, onSuccess, onError, onOpened, onProgress) {
			var xmlHttp = null;

			// Create an XML request.
			if (window.XMLHttpRequest) {
				xmlHttp = new XMLHttpRequest();
			} else if (window.ActiveXObject) {
				try {
					xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
				} catch (e) {
					try {
						xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
					} catch (e) {
						xmlHttp = null;
					}
				}
			}

			// XML request is unsupported.
			if (!xmlHttp) {
				if (typeof onError === "function") {
					onError(0);
				}
			}

			// Append session ID and token, if their are required.
			var s = url;
			if (withSession === true) {
				var userID = instance.getID();
				var token = instance.getToken();

				if (userID && token) {
					if (s.indexOf("?") >= 0) {
						s += "&";
					} else {
						s += "?";
					}
					s += "session=" + userID + "&token=" + token;
				}
				if (instance.app > 0) {
					s += "&app=" + instance.app;
				}
			}

			// Set callbacks.
			xmlHttp.open(method, s, true);
			xmlHttp.onreadystatechange = function() {
				if (xmlHttp.readyState === 1) {
					// Invoke the callback function for onOpened event.
					if (typeof onOpened === "function") {
						onOpened();
					}
					// Register the callback function for onProgress event.
					if (typeof onProgress === "function") {
						xmlHttp.upload.onprogress = onProgress;
					}
				} else if (xmlHttp.readyState === 4) {
					var status = 0;
					try {
						status = xmlHttp.status;
					} catch(e) {
						status = 0;
					}

					if (status === 200) {
						if (withSession === true) {
							var token = null;
							try {
								token = xmlHttp.getResponseHeader("token");
							} catch (e) {
								token = null;
							}
							if (token) {
								instance.setToken(token);
								instance.saveTokenToNative();
							}

							var timestamp = null;
							try {
								timestamp = xmlHttp.getResponseHeader("timestamp");
							} catch (e) {
								timestamp = null;
							}
							if (timestamp) {
								instance.setTime(timestamp);
							}
						}

						if (typeof onSuccess === "function") {
							onSuccess(xmlHttp);
						}
					} else {
						if (typeof onError === "function") {
							onError(status);
						}
					}
				}
			};

			// Send the request.
			xmlHttp.send(data);
		};

		return instance;
	}
};