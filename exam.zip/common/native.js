(function(root) {
    String.prototype.format = function() {
        var args = arguments;
        return this.replace(/\{(\d+)\}/g, function(m, i) {
            return args[i];
        });
    };
    String.prototype.format2 = function(cfg) {
        return this.replace(/\{(\w+)\}/g, function(m, i) {
            return cfg[i];
        });
    };
    var utils = {
        createUUID: function(interval) {
            if (!interval) {
                interval = '-';
            }
            var s = [];
            var hexDigits = '0123456789abcdef';
            for (var i = 0; i < 36; i++) {
                s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
            }
            s[14] = '4';
            s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1);
            s[8] = s[13] = s[18] = s[23] = interval;

            var uuid = s.join('');
            return uuid;
        },

        /**
         * @params {key: value}
         * */
        urlAddParams: function(url, params) {
            for (var key in params) {
                url = utils.urlAddParam(url, key, params[key]);
            }
            return url;
        },
        urlAddParam: function(url, paramName, paramValue) {
            var tagIndex = url.indexOf('?');
            var ret = url;
            var param = '{0}={1}'.format(paramName, encodeURIComponent(paramValue));
            if (tagIndex < 0) {
                ret = url += '?' + param;
            } else if (tagIndex < url.length - 1) {
                ret = url += '&' + param;
            } else if (tagIndex === url.length - 1) {
                ret = url += param;
            }
            return ret;
        },
        clone: function(srcObj) {
            if (!srcObj || 'object' !== typeof srcObj) {
                return srcObj;
            }

            var cloneObj, i;
            if (srcObj.constructor === Array) {
                cloneObj = [];
                for (i in srcObj) {
                    cloneObj[i] = utils.clone(srcObj[i]);
                }
            } else if (srcObj.constructor === Object /*|| typeof srcObj === 'object'*/ ) {
                cloneObj = {};
                for (i in srcObj) {
                    if (srcObj.hasOwnProperty(i)) {
                        cloneObj[i] = utils.clone(srcObj[i]);
                    }
                }
            } else {
                cloneObj = srcObj;
            }

            return cloneObj;
        }
    };
    var Class = {
        create: function(def) {
            var constructor = def['_init_'] || function() {};

            var prop, method, stc;
            var copyMethod = function(src, tar) {
                for (method in src) {
                    if (!tar[method]) {
                        tar[method] = src[method];
                    }
                }
            };
            var copyProp = function(src, tar) {
                var propVal = null;
                for (prop in src) {
                    propVal = tar[prop];
                    if (!propVal && propVal !== 0 && propVal !== '')
                        tar[prop] = utils.clone(src[prop]);
                }
            };

            var type = {
                create: function() {
                    copyMethod(type._method_, type._init_.prototype);
                    var evalStr = 'new type._init_({0})';
                    var args = Array.prototype.slice.call(arguments, 0);
                    for (var i in args) {
                        evalStr = evalStr.replace('{0}', 'args[' + i + '],{0}');
                    }
                    evalStr = evalStr.replace(',{0}', '').replace('{0}', '');
                    var obj = eval(evalStr);
                    copyProp(type._prop_, obj);
                    return obj;
                },
                extend: function(_def) {
                    var subType = cls.create(_def || {});
                    var constructor = subType._init_;
                    subType._init_ = function() {
                        type._init_.apply(this, arguments);
                        constructor.apply(this, arguments);
                    };
                    //copyMethod(type._prop_._super, subType._prop_._super)
                    //copyMethod(type._method_, subType._prop_._super);
                    copyMethod(type._method_, subType._method_);
                    copyProp(type._prop_, subType._prop_);
                    return subType;
                },
                _prop_: {
                    //_super: {}
                },
                _method_: {
                    _set_: function(prop, value) {
                        if (this.hasOwnProperty(prop))
                            this[prop] = value;
                    },
                    _get_: function(prop) {
                        if (this.hasOwnProperty(prop))
                            return this[prop];
                        else
                            return undefined;
                    }
                },
                _init_: constructor
            };

            for (prop in def._prop_) {
                type._prop_[prop] = def._prop_[prop];
            }
            for (method in def._method_) {
                type._method_[method] = def._method_[method];
            }
            for (stc in def._static_) {
                type[stc] = def._static_[stc];
            }

            return type;
        }
    };
    var browser = {
        versions: (function() {
            var u = navigator.userAgent;
            return {
                trident: u.indexOf('Trident') > -1,
                presto: u.indexOf('Presto') > -1,
                webKit: u.indexOf('AppleWebKit') > -1,
                gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1,
                mobile: !!u.match(/AppleWebKit.*Mobile.*/) || !!u.match(/AppleWebKit/),
                iOS: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/),
                android: u.indexOf('Android') > -1,
                iPhone: u.indexOf('iPhone') > -1,
                iPad: u.indexOf('iPad') > -1,
                webApp: u.indexOf('Safari') == -1,
                miPad: u.indexOf('MI') > -1 && u.indexOf('PAD') > -1
            };
        })(),

        language: (navigator.browserLanguage || navigator.language).toLowerCase()
    };
    var Evt = Class.create({
        _init_: function() {},
        _method_: {
            addListener: function(func) {
                if (!func)
                    return;
                var id = String(func);
                if (!this.listeners[id]) {
                    this.listeners[id] = func;
                    this.count++;
                }
            },
            removeListener: function(func) {
                if (!func)
                    return;
                var id = String(func);
                if (this.listeners[id]) {
                    delete this.listeners[id];
                    this.count--;
                }
            },
            removeAllListeners: function() {
                for (var i in this.listeners) {
                    delete this.listeners[i];
                }
                this.count = 0;
            }
        },
        _prop_: {
            listeners: {},
            count: 0
        }
    });
    var EventBox = Class.create({
        _init_: function() {},
        _method_: {
            addEventListener: function(name, func) {
                if (!func || !name)
                    return;

                var event = this.holder[name];
                if (!event) {
                    event = this.evt.create();
                    this.holder[name] = event;
                }

                event.addListener(func);
            },
            removeEventListener: function(name, func) {
                if (!name) {
                    return;
                }

                var event = this.holder[name];
                if (event) {
                    if (func)
                        event.removeListener(func);
                    else
                        event.removeAllListeners();
                    if (event.count === 0) {
                        delete this.holder[name];
                    }
                }
            },
            trigger: function(name) {
                if (!name)
                    return;

                var i, event, listener;
                event = this.holder[name];
                if (event) {
                    var args = Array.prototype.slice.call(arguments, 1);
                    for (i in event.listeners) {
                        listener = event.listeners[i];
                        listener.apply(this, args);
                    }
                }
            }
        },
        _prop_: {
            holder: {},
            evt: Evt
        }
    });
    var NativeClass = Class.create({
        _init_: function() {
            this._eventBox = EventBox.create();
        },
        _method_: {
            notifyDomReady: function(cb) {
                var nativeUrl = NativeClass.NATIVE_PREFIX + NativeClass.NATIVE_DOM_READY;
                var evtKey = this._createEventKey();
                this._eventBox.addEventListener(evtKey, this._createCallback(evtKey, cb));
                nativeUrl = utils.urlAddParams(nativeUrl, {
                    _evt: evtKey
                });
                this._addNotify(nativeUrl);
            },
            notifyHttpGet: function(url, params, cb) {
                var nativeUrl = NativeClass.NATIVE_PREFIX + NativeClass.NATIVE_HTTP_GET;
                var evtKey = this._createEventKey();
                this._eventBox.addEventListener(evtKey, this._createCallback(evtKey, cb));
                nativeUrl = utils.urlAddParams(nativeUrl, {
                    url: url,
                    data: JSON.stringify(params || {}),
                    _evt: evtKey
                });
                this._addNotify(nativeUrl);
            },
            notifyHttpPost: function(url, params, cb) {
                var nativeUrl = NativeClass.NATIVE_PREFIX + NativeClass.NATIVE_HTTP_POST;
                var evtKey = this._createEventKey();
                this._eventBox.addEventListener(evtKey, this._createCallback(evtKey, cb));
                nativeUrl = utils.urlAddParams(nativeUrl, {
                    url: url,
                    data: JSON.stringify(params || {}),
                    _evt: evtKey
                });
                this._addNotify(nativeUrl);
            },
            notifyCallMethod: function(methodName, params, cb) {
                var nativeUrl = NativeClass.NATIVE_PREFIX + NativeClass.NATIVE_CALL;
                var evtKey = this._createEventKey();
                this._eventBox.addEventListener(evtKey, this._createCallback(evtKey, cb));
                nativeUrl = utils.urlAddParams(nativeUrl, {
                    method: methodName,
                    data: JSON.stringify(params || {}),
                    _evt: evtKey
                });
                this._addNotify(nativeUrl);
            },
            /* call by native */
            _triggerEvent: function(evtKey) {
                this._eventBox.trigger.apply(this._eventBox, arguments);
                this._notifyQueue = this._notifyQueue.slice(1);
                this._processing = false;
                this._scanQueue();
            },
            _scanQueue: function() {
                if (this._notifyQueue.length > 0 && !(this._processing)) {
                    this._processing = true;
                    var thiz = this;
                    setTimeout(function() {
                        if (browser.versions.iOS) {
                            location.href = thiz._notifyQueue[0];
                        } else if (browser.versions.android) {
                            var img = document.createElement('img');
                            img.src = thiz._notifyQueue[0];
                            img.style.display = 'none';
                            document.body.appendChild(img);
                        }
                    }, 0);
                }
            },
            _addNotify: function(nativeUrl) {
                this._notifyQueue.push(nativeUrl);
                if (this._notifyQueue.length === 1) {
                    this._scanQueue();
                }
            },
            _createEventKey: function() {
                return utils.createUUID();
            },
            _createCallback: function(evtKey, cb) {
                var callbackAdapter = (function(evtKey, cb, thiz) {
                    return function() {
                        thiz._eventBox.removeEventListener(evtKey);
                        if (cb) {
                            cb.apply(thiz, arguments);
                        }
                    }
                })(evtKey, cb, this);
                return callbackAdapter;
            }
        },
        _prop_: {
            _eventBox: null,
            _notifyQueue: [],
            _processing: false
        },
        _static_: {
            NATIVE_PREFIX: 'native://',
            NATIVE_DOM_READY: 'ready',
            NATIVE_HTTP_GET: 'http-get',
            NATIVE_HTTP_POST: 'http-post',
            NATIVE_CALL: 'call'
        }
    });
    root.Native = NativeClass.create();
})(window);