var space = (function() {
	var g = {};

	g.config = {
		// prefix: window.location.protocol + "//live-t.gaodun.com",
		prefix: window.location.protocol + "//live-hz.gaodun.com",
		// prefix: window.location.protocol + "//live-pre.gaodun.com",
		slidesServer: window.location.protocol + "//gaodun-uploadfiles.oss-cn-hangzhou.aliyuncs.com/cw/",
		examServer: window.location.protocol + "//gaodun-uploadfiles.oss-cn-hangzhou.aliyuncs.com/exam/",
		coverServer: window.location.protocol + "//video1-cdn.gaodun.com/pub/",
		// examServer: window.location.protocol + "//gaodun-uploadfiles.oss-cn-hangzhou.aliyuncs.com/test/exam/",
		app: 0,
		storageKey: "gData",
		useLocalStorage: (function() {
			try {
				return localStorage ? true : false;
			} catch (e) {
				return false;
			}
		})()
	};

	g.setApp = function(n) {
		space.config.app = n;
		space.sender.app = n;
	};
	g.isApp = function() {
		return space.config.app === 0 ? false : true;
	};

	g.isFunction = function(f) {
		return (typeof f === "function");
	};
	g.isSystem = function() {
		switch (g.data.me.role) {
			case "SYSTEM":
			case "ASSISTANT":
			case "KEEPER":
			case "TEACHER":
				return true;

			default:
				return false;
		}
	};
	g.isStudent = function() {
		return (g.data.me.role === "STUDENT");
	};

	//----------------------------------------------------
	// String-related methods.

	g.formatTime = function(ms, short) {
		var n2s = function(n) {
			return (n >= 10) ? (n.toString()) : ("0" + n.toString());
		};

		var t = new Date(ms);

		var s = t.getFullYear() + "-" + n2s(t.getMonth() + 1) + "-" + n2s(t.getDate());
		if (short === true) {
			return s;
		}
		return s + " " + n2s(t.getHours()) + ":" + n2s(t.getMinutes());
	};
	g.formatDuration = function(seconds) {
		var d = seconds;

		var days = Math.floor(d / (24 * 60 * 60));
		if (days > 0) {
			d -= days * 24 * 60 * 60;
		}

		var hours = Math.floor(d / (60 * 60));
		if (hours > 0) {
			d -= hours * 60 * 60;
		}

		var minutes = Math.floor(d / 60);
		if (minutes > 0) {
			d -= minutes * 60;
		}

		var r = (hours >= 10 ? hours : ("0" + hours)) + ":" +
			(minutes >= 10 ? minutes : ("0" + minutes));
		if (days > 0) {
			return days + " " + r;
		}

		return r;
	};

	//----------------------------------------------------
	// Data-related methods.

	g.initData = function() {
		g.data = {
			COMPONENT: {
				UNKNOWN: 0,
				GROUP: 1,
				CLASS: 2,
				SUBCLASS: 3,
				MEETING: 4,
				EXAM: 5,
				REPLAY: 6,
				SLIDES: 7,
				VIDEO: 8
			},

			me: {
				id: 0,
				nickname: "",
				role: ""
			},

			users: {},
			invitationTokens: [],

			groups: [],
			classes: [], // Array of class objects within current group or paid list.
			subclasses: [],
			meetings: [], // Array of meeting objects within current class.
			teachers: [], // Array of user IDs within current class.
			students: {}, // Array of user IDs within current class.

			progresses: {}, // Map from class ID to object of users' progresses.
			myProgress: [],

			timestamp: 0,

			currentGroup: 0,
			currentGroupName: "",
			currentClass: 0,
			currentMeeting: 0,
			currentVideo: 0,
			currentComponent: 0
		};

		if (g.config.useLocalStorage) {
			localStorage.removeItem(g.config.storageKey);
		}
	};
	g.saveData = function() {
		if (g.config.useLocalStorage) {
			localStorage.setItem(g.config.storageKey, JSON.stringify(g.data));
		}
	};
	g.loadData = function() {
		var s = null;
		if (g.config.useLocalStorage) {
			s = localStorage.getItem(g.config.storageKey);
		}
		if (s === null) {
			g.data = {};
			return false;
		}

		try {
			g.data = JSON.parse(s);
		} catch (e) {
			g.data = {};
			return false;
		}
		
		return true;
	};
	g.removeData = function() {
		g.data = {};

		if (g.config.useLocalStorage) {
			localStorage.removeItem(g.config.storageKey);
		}
	};

	//----------------------------------------------------

	if (RequestSender) {
		g.sender = RequestSender.createNew(g.config.prefix, g.config.useLocalStorage, g.config.app);
	}

	//----------------------------------------------------

	if (!g.loadData()) {
		g.initData();
	}

	//----------------------------------------------------
	// System-related methods.

	g.getMeetingConfig = function(meetingID, onCallback) {
		g.sender.invoke(
			"/meeting/config/get?meeting=" + meetingID,
			false,
			onCallback
		);
	};

	//----------------------------------------------------
	// User-related methods.

	g.loginAsGaodunUser = function(userName, userPassword, onCallback) {
		g.sender.clearSession();
		g.sender.invoke(
			"/gaodun/login?name=" + encodeURIComponent(userName) + "&password=" + encodeURIComponent(userPassword),
			true,
			onCallback
		);
	};

	g.register = function(userName, userPassword, token, onCallback) {
		g.sender.clearSession();
		g.sender.invoke(
			"/user/register?name=" + encodeURIComponent(userName) + "&password=" + Hash.md5(userPassword) + "&token=" + encodeURIComponent(token),
			true,
			onCallback
		);
	};
	g.login = function(userName, userPassword, onCallback) {
		g.sender.clearSession();
		g.sender.invoke(
			"/user/login?name=" + encodeURIComponent(userName) + "&password=" + Hash.md5(userPassword),
			true,
			function(resp) {
				if (resp.status === 0) {
					g.data.me = resp.result;

					g.sender.setID(g.data.me.id);

					if (g.isSystem()) {
						g.queryGroup(onCallback);
					} else {
						g.queryClass(onCallback);
					}
				} else {
					if (g.isFunction(onCallback)) {
						onCallback(resp);
					}
				}
			}
		);
	};
	g.logout = function(onCallback) {
		g.initData();
		g.sender.clearSession();

		if (g.isFunction(onCallback)) {
			onCallback(resp);
		};

		window.location.reload();
	};
	g.changePassword = function(oldPassword, newPassword, onCallback) {
		g.sender.invoke(
			"/user/password/change?oldPassword=" + Hash.md5(oldPassword) + "&password=" + Hash.md5(newPassword),
			true,
			onCallback
		);
	};
	g.changeProfile = function(nickname, mail, phone, qq, onCallback) {
		g.sender.invoke(
			"/user/profile/change?nickname=" + encodeURIComponent(nickname) + "&mail=" + encodeURIComponent(mail) + "&phone=" + encodeURIComponent(phone) + "&qq=" + encodeURIComponent(qq),
			true,
			function(resp) {
				if (resp.status === 0) {
					g.data.me.nickname = nickname;
					g.saveData();
				}
				if (g.isFunction(onCallback)) {
					onCallback(resp);
				}
			}
		);
	};

	g.queryGroup = function(onCallback, onError) {
		g.sender.invoke(
			"/user/group/query",
			true,
			function(resp) {
				if (resp.status === 0) {
					g.data.groups = resp.result.group;
				}
				if (g.isFunction(onCallback)) {
					onCallback(resp);
				};
			},
			onError
		);
	};

	//----------------------------------------------------
	// Class-related methods.

	g.getPlatformName = function(id) {
		switch (id) {
			case 0:
				return "GLive";
			case 1:
				return "Gensee";
			case 2:
				return "BokeCC";
			case 4:
				return "Sale";
			case 5:
				return "Package";
			default:
				return id.toString();
		}
	};
	g.isNotPackage = function(klass) {
		return (klass.platformID !== 5);
	};

	g.queryClass = function(onCallback, onError) {
		var params = "";
		if (g.isSystem()) {
			params += "?group=" + g.data.currentGroup;
		}
		g.sender.invoke(
			"/class/query" + params,
			true,
			function(resp) {
				if (resp.status === 0) {
					g.data.classes = resp.result.classList;
					// g.data.currentGroup = g.data.currentGroup;
					g.data.currentComponent = g.data.COMPONENT.CLASS;
					g.saveData();
				}
				if (g.isFunction(onCallback)) {
					onCallback(resp);
				}
			},
			onError
		);
	};
	g.querySubClass = function(classID, onCallback) {
		g.sender.invoke(
			"/class/subclass/query?class=" + classID,
			true,
			function(resp) {
				if (resp.status === 0) {
					g.data.subclasses = resp.result.classList;
					g.data.currentComponent = g.data.COMPONENT.SUBCLASS;
					g.saveData();
				}
				if (g.isFunction(onCallback)) {
					onCallback(resp);
				}
			}
		);
	};
	g.queryClassBriefs = function(gaodunStudentID, onCallback) {
		g.sender.invoke(
			"/gaodun/class/query?gaodunStudentID=" + gaodunStudentID,
			true,
			onCallback
		);
	};

	g.queryTeacherByClass = function(classID, onCallback) {
		g.sender.invoke(
			"/class/teacher/query?class=" + classID,
			true,
			function(resp) {
				if (resp.status === 0) {
					g.data.teachers = [];
					for (var userID in resp.result.user) {
						g.data.teachers.push({
							id: userID,
							nickname: resp.result.user[userID].nickname
						});
					}
				}

				if (g.isFunction(onCallback)) {
					onCallback(resp);
				}
			}
		);
	};

	g.queryStudentByClass = function(classID, onCallback) {
		g.sender.invoke(
			"/class/student/query?class=" + classID,
			true,
			function(resp) {
				if (resp.status === 0) {
					g.data.students = resp.result.user;
				}
				if (g.isFunction(onCallback)) {
					onCallback(resp);
				}
			}
		);
	};

	//----------------------------------------------------
	// Meeting-related methods.

	g.getMeetingTypeName = function(id) {
		switch (id) {
			case 0:
				return "Live";
			case 1:
				return "Live | Mock";
			case 2:
				return "Mock";
			default:
				return id.toString();
		}
	};

	g.getMeeting = function(meetingID, onCallback) {
		g.sender.invoke(
			"/meeting/get?meeting=" + meetingID,
			true,
			onCallback
		);
	};

	g.queryMeeting = function(classID, onCallback, onError) {
		g.sender.invoke(
			"/class/meeting/query?class=" + classID,
			true,
			function(resp) {
				if (resp.status === 0) {
					space.data.currentClass = classID;
					space.data.meetings = resp.result.meeting;
					space.data.currentComponent = space.data.COMPONENT.MEETING;

					if (space.isStudent()) {
						space.queryMyProgress(classID, onCallback);
						return;
					} else {
						space.saveData();
					}
				}

				if (space.isFunction(onCallback)) {
					onCallback(resp);
				}
			},
			onError
		);
	};
	g.queryMeetingByGaodunCourseID = function(gaodunCourseID, onCallback, onError) {
		g.sender.invoke(
			"/gaodun/meeting/query?gaodunCourseID=" + gaodunCourseID,
			true,
			function(resp) {
				if (resp.status === 0) {
					space.data.me.id = resp.result.user;
					space.data.me.nickname = resp.result.nickname;
					space.data.me.role = "STUDENT";

					space.data.currentClass = resp.result.class;
					
					space.data.meetings = resp.result.meeting;
					space.data.currentComponent = space.data.COMPONENT.MEETING;

					if (space.isStudent()) {
						space.queryMyProgress(resp.result.class, onCallback);
						return;
					} else {
						space.saveData();
					}
				}

				if (space.isFunction(onCallback)) {
					onCallback(resp);
				}
			},
			onError
		);
	};
	g.joinMeeting = function(meetingID, onCallback) {
		g.sender.invoke(
			"/meeting/join?meeting=" + meetingID,
			true,
			onCallback
		);
	};

	g.queryProgressByMeeting = function(meetingID, onCallback) {
		g.sender.invoke(
			"/meeting/progress/query?meeting=" + meetingID,
			true,
			onCallback
		);
	};

	g.authorizeVideos = function(meetingID, onCallback) {
		g.sender.invoke(
			"/meeting/video/authorize?meeting=" + meetingID,
			true,
			onCallback
		);
	};
	g.authorizeReplays = function(meetingID, onCallback) {
		g.sender.invoke(
			"/meeting/replay/authorize?meeting=" + meetingID,
			true,
			onCallback
		);
	};

	//----------------------------------------------------
	// Exam-related methods.

	g.answerArray2HexString = function(arr) {
		if (!arr || arr.length === 0) {
			return "";
		}

		var result = "";
		for (var i = 0; i < arr.length; i++) {
			var answer = arr[i];

			// Check the answer itself.
			if (!g.Methods.isValid(answer) || answer.length === 0) {
				result += "00";
				continue;
			}

			// Get its binary value.
			var b = 0x00;
			for (var j = 0; j < answer.length; j++) {
				if (answer[j] !== '0') {
					b |= (0x01 << j);
				}
			}

			// Translate this byte to HEX string.
			var s = b.toString(16);
			if (s.length === 1) {
				result += "0";
			}
			result += s;
		}
		return result;
	};

	g.getExam = function(meetingID, examID, onCallback) {
		var key = "";
		var iv = "";
		var onSuccess = function(xhr) {
			if (space.isFunction(onCallback)) {
				var s = xhr.responseText;
				var bytes = CryptoJS.AES.decrypt(
					s,
					CryptoJS.enc.Hex.parse(key),
					{
						iv: CryptoJS.enc.Hex.parse(iv),
						mode: CryptoJS.mode.CBC,
						padding: CryptoJS.pad.Pkcs7
					}
				);

				onCallback({
					status: 0,
					info: "Okay.",
					result: {
						exam: eval("(" + bytes.toString(CryptoJS.enc.Utf8) + ")")
					}
				});
			}
		};
		var onError = function(n) {
			if (space.isFunction(onCallback)) {
				onCallback({
					status: (n === 0 ? -1 : -2),
					info: "Network error.",
					result: null
				});
			}
		};

		g.sender.invoke(
			"/meeting/exam/authorize?meeting=" + meetingID + "&exam=" + examID,
			true,
			function(resp) {
				if (resp.status === 0) {
					key = resp.result.key;
					iv = resp.result.iv;

					g.sender.download(
						g.config.examServer + examID,
						onSuccess,
						onError
					);
				} else {
					if (space.isFunction(onCallback)) {
						onCallback(resp);
					}
				}
			}
		);
	};
	g.getExamAnswer = function(meetingID, examID, onCallback) {
        g.sender.invoke(
            "/meeting/exam/answer/get?meeting=" + meetingID + "&exam=" + examID,
            true,
            onCallback
        );
    };

	g.downloadSlides = function(slides, onError) {
		g.sender.download(
			space.config.slidesServer + slides.id + ".pdf",
			function(xhr) {
				var a = ui.el("a");
				a.href = window.URL.createObjectURL(xhr.response);
				a.download = slides.name + ".pdf";
				a.click();
			},
			onError
		);
	};

	return g;
})();