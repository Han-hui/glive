var statistics = (function() {
	var g = {};

	var createMeetingProgress = function(meetingID) {
		var r = {
			meetingID: meetingID,

			attendanceCount: 0,
			attendanceTotal: 0,

			examCorrect: 0,
			examTotalForCorrect: 0,

			examFinished: 0,
			examTotalForFinished: 0,

			preparationFinished: 0,
			preparationTotal: 0,

			score: 0
		};

		return r;
	};

	g.findCurrentMeeting = function(meetings) {
		// Check inputs.
		if (!meetings || meetings.length === 0) {
			return -1;
		}
		if (meetings.length === 1) {
			return 0;
		}

		// Sort meetings according to their start time and end time.
		meetings.sort(
			function(a, b) {
				// Check their start time at first.
				var d = a.startTime - b.startTime;
				if (d !== 0) {
					return d;
				}

				// Then check their end time.
				if (a.endTime === 0) {
					if (b.endTime === 0) {
						return 0;
					} else {
						// Let b < a.
						return 1;
					}
				} else {
					if (b.endTime === 0) {
						// Let a < b.
						return -1;
					} else {
						return a.endTime - b.endTime;
					}
				}
			}
		);

		// Find the current meeting.
		var now = (new Date()).getTime();
		for (var i = 0; i < meetings.length; i++) {
			var m = meetings[i];
			if (m.endTime > 0) {
				continue;
			}
			if (m.startTime < now) {
				return i;
			}
		}

		// Return the last meeting.
		return (meetings.length - 1);
	};

	var attachProgressToMeeting = function(meetings, progresses) {
		if (!meetings) {
			return;
		}
		if (!progresses) {
			for (var i = 0; i < meetings.length; i++) {
				meetings[i].p = null;
			}
			return;
		}

		for (var i = 0; i < meetings.length; i++) {
			meetings[i].p = null;
			for (var j = 0; j < progresses.length; j++) {
				if (meetings[i].id === progresses[j].meetingID) {
					meetings[i].p = progresses[j];
					break;
				}
			}
		}
	};

	var computeOverallScore = function(m, p) {
		if (!p) {
			return;
		}

		var sum = 1;
		if (m.courseware.length > 0) {
			sum ++;
		}
		if (m.exam.length > 0) {
			sum ++;
		}
		if (m.video.length > 0) {
			sum ++;
		}

		p.score = Math.floor(
			(
				(p.studyTimeTotal === 0 ? 0 : (p.attendanceCount / p.attendanceTotal)) +
				(p.examTotalForCorrect === 0 ? 0 : (p.examCorrect / p.examTotalForCorrect)) +
				(p.preparationTotal === 0 ? 0 : (p.preparationFinished / p.preparationTotal)) +
				(p.examTotalForFinished === 0 ? 0 : (p.examFinished / p.examTotalForFinished))
			) * 100.0 / sum
		);
	};

	g.summerizeMyProgresses = function(meetings, progresses) {
		var r = [];

		attachProgressToMeeting(meetings, progresses);
		var now = g.findCurrentMeeting(meetings);
		for (var i = 0; i <= now; i++) {
			if (!(meetings[i].p)) {
				continue;
			}

			var mp = createMeetingProgress(meetings[i].id);

			// Step 1.

			if (meetings[i].meeting > 0) {
				mp.attendanceCount =  1;
			}
			mp.attendanceTotal = 1;

			// Step 2.

			mp.examCorrect = meetings[i].p.examCorrect;
			mp.examTotalForCorrect = meetings[i].p.examTotal;

			// Step 3.

			for (var j = 0; j < meetings[i].exam.length; j ++) {
				if (meetings[i].exam[j].necessary === 0) {
					continue;
				}

				mp.examTotalForFinished ++;
				if (meetings[i].p.exam[meetings[i].exam[j].id]) {
					mp.examFinished ++;
				}
			}

			// Step 4.

			for (var j = 0; j < meetings[i].courseware.length; j ++) {
				if (meetings[i].courseware[j].necessary === 0 || meetings[i].courseware[j].preparation === 0) {
					continue;
				}

				mp.preparationTotal ++;
				if (meetings[i].p.courseware === 1) {
					mp.preparationFinished ++;
				}
			}
			for (var j = 0; j < meetings[i].video.length; j ++) {
				if (meetings[i].video[j].necessary === 0 || meetings[i].video[j].preparation === 0) {
					continue;
				}

				mp.preparationTotal ++;
				if (meetings[i].p.video === 1) {
					mp.preparationFinished ++;
				}
			}

			computeOverallScore(meetings[i], mp);
			r.push(mp);
		}

		return r;
	};

	return g;
})();