var Editor = Editor || {
	createNew: function(parent) {
		var instance = {
			parent: parent
		};

		var root = document.createElement("p");
		root.setAttribute("contenteditable", "true");
		instance.parent.appendChild(root);

		var span = document.createElement("span");
		span.innerText = "Input your content here.";
		span.id = "s";
		root.appendChild(span);

		// Math related functions.
		var mathEditor = MathEditor.createNew(root);
		instance.frac = function() {
			mathEditor.newEdit("\\frac{a}{b}");
		};
		instance.sqrt = function() {
			mathEditor.newEdit("\\sqrt{a}");
		};

		instance.value = function() {
			var s = "";
			for (var i = 0; i < root.children.length; i ++) {
				var c = root.children[i];
				if (c.id) {
					if (c.id.indexOf("m") === 0) {
						var mf = mathEditor.fields[c.id];
						if (mf) {
							s += "[emb]m"+mf.latex()+"[/emb]";
						}
					} else if (c.id.indexOf("t") === 0) {
						// This is a table.
					} else if (c.id.indexOf("s") === 0) {
						s += c.innerText;
					}
				// } else {
				// 	s += c.innerText;
				}
			}
			return s;
		};

		return instance;
	}
};
