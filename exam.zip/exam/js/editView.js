var EditViewer = EditViewer || {
	createNew: function(parent) {
		var instance = {
			mq: MathQuill.getInterface(2),
			parent: parent
		};

		var root = document.createElement("p");
		instance.parent.appendChild(root);

		var renderString = function(s) {
			if ((typeof s === "string") && (s.length > 0)) {
				var span = document.createElement("span");
				span.className = "text";
				span.innerText = s;
				root.appendChild(span);
			}
		};
		var renderFormula = function(s) {
			if ((typeof s === "string") && (s.length > 0)) {
				var span = document.createElement("span");
				span.className = "formula";
				span.innerText = s;
				root.appendChild(span);

				instance.mq.StaticMath(span);
			}
		};
		var renderTable = function(s) {
			if ((typeof s === "string") && (s.length > 0)) {
				var span = document.createElement("span");
				span.className = "table";
				var table = document.createElement("table");
				table.innerHTML = s;
				span.appendChild(table);
				root.appendChild(span);
			}
		};

		instance.render = function(s) {
			if (typeof s !== "string" || s.length === 0) {
				return;
			}
			root.innerHTML = "";

			var tmp = "";
			var n = s.length;
			var start = 0;
			for (var i = 0; i < n; i++) {
				if (n - 1 > 5) {
					if ((s[i] === '[') &&
						(s[i + 1] === 'e') &&
						(s[i + 2] === 'm') &&
						(s[i + 3] === 'b') &&
						(s[i + 4] === ']')) {

						i += 5;
						start = i;
						while (n - i > 5) {
							if ((s[i] === '[') &&
								(s[i + 1] === '/') &&
								(s[i + 2] === 'e') &&
								(s[i + 3] === 'm') &&
								(s[i + 4] === 'b') &&
								(s[i + 5] === ']')) {
								switch (s[start]) {
									case 'f':
										renderFormula(s.substring(start + 1, i));
										break;
									case 't':
										renderTable(s.substring(start + 1, i));
										break;
									case 's':
										renderString(s.substring(start + 1, i));
										break;
								}

								// i += 6;
								break;
							} else {
								i++;
							}
						}
					}
				}
			}
		};

		return instance;
	}
};