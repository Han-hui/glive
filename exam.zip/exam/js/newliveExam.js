var LiveExam = {
    createNew: function(meetingID, startTime, duration, examID, meetingName,isRedo) {
        var instance = {
            answerObj: {},
            int: null,
            originalQuestion: {},
            startTime: startTime,
            duration: duration,
            meetingID: meetingID,
            examID: examID,
            meetingName: meetingName,
            isRedo:isRedo,
            storageDate: {},

            currentQuestion: null,
            currentSynthesisQuestion: null,

            subjective: {},
            flag:null,
            userid: parseInt(localStorage.getItem("id")),
        };

        instance.begin = function() {
            $('.countDown').hide();
            queryExam();
        };
        //
        $(".timeup_submit_modal .submit").unbind('click');
        $(".timeup_submit_modal .submit").click(function() {
            $(".timeup_submit_modal").removeClass("is_visible");
            // 提交答案
            postAnswer();
        });
        //
        var queryExam = function() {
            space.getExam(
                instance.meetingID,
                instance.examID,
                function(resp) {
                    if (resp.status === 0) {
                        instance.originalQuestion = resp.result.exam;
                        meetingQueryProgress(resp.result.exam);
                    } else {
                        console.log(resp);
                    }
                }
            );

        };

        // Check Do
        var meetingQueryProgress = function(questionObj) {
            var questionNum = [];
            space.queryProgressByMeeting(instance.meetingID,
                function(obj) {
                    if (obj.status === 0) {

                        if(obj.result.progress){
                            instance.flag = false;
                        }else{
                            instance.flag = true;
                        }
                        if (instance.flag&&obj.result.exam[instance.examID]&&!instance.isRedo) {
                            space.getExamAnswer(
                                instance.meetingID,
                                instance.examID,
                                function(resp) {
                                    // var subjectAnswer = eval("(" + resp.responseText + ")");
                                    var subjectAnswer = resp;
                                    var userExamAnswer = resp.result.objective;
                                    // for( var i = 0;i < obj.result.exam.length;i++ ){
                                    // 	if( obj.result.exam[i].id === instance.examID ){
                                    // 		userExamAnswer = obj.result.exam[i].answer;
                                    // 	}
                                    // }

                                    var v = 0;
                                    var lookOverObj = {};
                                    var answerArray = [];
                                    for (var i = 0; i < questionObj.subject.length; i++) {
                                        for (var j = 0; j < questionObj.subject[i].question.length; j++) {
                                            if (questionObj.subject[i].question[j].choice === undefined) {
                                                var id = questionObj.subject[i].question[j].id;
                                                if (id === undefined) {
                                                    v--;
                                                    id = v;
                                                }
                                                questionNum.push(id);

                                                for (var z = 0; z < questionObj.subject[i].question[j].question.length; z++) {
                                                    var userAnswer = questionObj.subject[i].question[j].question[z].userAnswer;
                                                    if (userAnswer === undefined) {
                                                        userAnswer = 0;
                                                    }
                                                }
                                                lookOverObj[id] = questionObj.subject[i].question[j];
                                            } else {
                                                var id = questionObj.subject[i].question[j].id;
                                                questionNum.push(id);

                                                if (questionObj.subject[i].question[j].userAnswer === undefined) {
                                                    questionObj.subject[i].question[j].userAnswer = 0;
                                                }
                                                lookOverObj[id] = questionObj.subject[i].question[j];
                                            }
                                        }
                                    }
                                    for (var z = 0; z < userExamAnswer.length; z += 2) {
                                        answerArray.push(userExamAnswer.substring(z, z + 2));
                                    }
                                    for (var k in lookOverObj) {
                                        if (lookOverObj[k].choice !== undefined) {
                                            if ((lookOverObj[k].type === 4) || (lookOverObj[k].type === 6)) {
                                                // delete newArr[instance.answerObj[k].id - 1];
                                                answerArray.splice(lookOverObj[k].id - 1, 0, "00");
                                            }
                                        } else {
                                            for (var j = 0; j < lookOverObj[k].question.length; j++) {
                                                if ((lookOverObj[k].question[j].type === 4) || (lookOverObj[k].question[j].type === 6)) {
                                                    // delete newArr[instance.answerObj[k].question[j].id - 1];
                                                    answerArray.splice(lookOverObj[k].question[j].id - 1, 0, "00");
                                                }
                                            }
                                        }
                                    }
                                    for (var k in lookOverObj) {
                                        if (lookOverObj[k].choice !== undefined) {
                                            var type = lookOverObj[k].type;
                                            if ((type !== 4) && (type !== 6)) {
                                                lookOverObj[k].userAnswer = Str2Bytes(answerArray[(lookOverObj[k].id - 1)]);
                                                var r = 0x00;
                                                for (var i = 0; i < lookOverObj[k].answer.length; i++) {
                                                    if (lookOverObj[k].answer[i] === "1") {
                                                        r |= (0x01 << i);
                                                    }
                                                }
                                                lookOverObj[k].answer = r;
                                            } else {

                                                lookOverObj[k].userAnswer = "";
                                                for (var key in subjectAnswer.result.subjective) {
                                                    if (Number(key) === lookOverObj[k].id) {
                                                        var s = LZString.decompressFromBase64(decodeURIComponent(subjectAnswer.result.subjective[key]));
                                                        lookOverObj[k].userAnswer = s;
                                                    }
                                                }

                                            }
                                        } else {
                                            for (var i = 0; i < lookOverObj[k].question.length; i++) {
                                                var type = lookOverObj[k].question[i].type;
                                                if ((type !== 4) && (type !== 6)) {
                                                    lookOverObj[k].question[i].userAnswer = Str2Bytes(answerArray[(lookOverObj[k].question[i].id - 1)]);
                                                    var r = 0x00;
                                                    for (var j = 0; j < lookOverObj[k].question[i].answer.length; j++) {
                                                        if (lookOverObj[k].question[i].answer[j] === "1") {
                                                            r |= (0x01 << j);
                                                        }
                                                    }
                                                    lookOverObj[k].question[i].answer = r;
                                                } else {
                                                    lookOverObj[k].question[i].userAnswer = "";
                                                    for (var key in subjectAnswer.result.subjective) {
                                                        if (Number(key) === lookOverObj[k].question[i].id) {
                                                            var us = subjectAnswer.result.subjective[key];
                                                            var s = LZString.decompressFromBase64(decodeURIComponent(us));
                                                            lookOverObj[k].question[i].userAnswer = s;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    showPersonalScore(lookOverObj, true);
                                    //for shandygaff
                                    showAnswerUI(lookOverObj, true);
                                    // end
                                    localStorage.setItem("isSubmit",true);
                                }
                            );
                        } else {
                            var ishave = true;
                            var l = window.localStorage.getItem("userAnswer");
                            if (l === null) {
                                ishave = false;
                            } else {
                                var sa = eval("(" + l + ")");
                                if (sa[instance.examID] === undefined) {
                                    ishave = false;
                                } else {
                                    ishave = true;
                                }
                            }

                            if (ishave === false) {
                                var a = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f"];
                                var s = "";
                                var storageAnswer = [];
                                for (var i = 0; i < instance.originalQuestion.count; i++) {
                                    storageAnswer.push(0);
                                }
                                for (var i = 0; i < storageAnswer.length; i++) {
                                    // 字节 转 16进制
                                    var c = (storageAnswer[i] & 0xF0) >> 4;
                                    s += a[c];
                                    c = storageAnswer[i] & 0x0F;
                                    s += a[c];
                                }
                                var sArray = [];
                                for (var i = 0; i < s.length; i += 2) {
                                    sArray.push(s.substring(i, i + 2));
                                }
                                instance.storageDate[instance.examID] = sArray;
                                window.localStorage.setItem("userAnswer", JSON.stringify(instance.storageDate));
                            }
                            l = window.localStorage.getItem("userAnswer");
                            var sa = eval("(" + l + ")");
                            var sArray = sa[instance.examID];

                            var v = 0;
                            for (var i = 0; i < questionObj.subject.length; i++) {
                                for (var j = 0; j < questionObj.subject[i].question.length; j++) {
                                    if (questionObj.subject[i].question[j].choice === undefined) {
                                        if (questionObj.subject[i].question[j].id === undefined) {
                                            v--;
                                            questionObj.subject[i].question[j].id = v;
                                        }
                                        questionNum.push(questionObj.subject[i].question[j].id);

                                        for (var z = 0; z < questionObj.subject[i].question[j].question.length; z++) {
                                            if (questionObj.subject[i].question[j].question[z].userAnswer === undefined) {
                                                questionObj.subject[i].question[j].question[z].userAnswer = Str2Bytes(sArray[(questionObj.subject[i].question[j].question[z].id - 1)]);
                                            }
                                        }
                                        instance.answerObj[questionObj.subject[i].question[j].id] = questionObj.subject[i].question[j];
                                    } else {
                                        var id = questionObj.subject[i].question[j].id;
                                        questionNum.push(id);

                                        if (questionObj.subject[i].question[j].userAnswer === undefined) {
                                            questionObj.subject[i].question[j].userAnswer = Str2Bytes(sArray[(id - 1)]);
                                        }
                                        instance.answerObj[id] = questionObj.subject[i].question[j];
                                    }
                                }
                            }

                            var newQuestionNum = questionNum;
                            // var newQuestionNum = questionNum.sort(function() {
                            // 	return Math.random() - 0.5;
                            // });

                            examUI(newQuestionNum);
                            //for shandygaff
                            $(".document-main-box").css("display", "none");
                            //end

                        }
                        // 请求试卷
                        //for shandygaff
                        $('#examContent,.exam_box').show();
                        // end
                    }
                }
            );
        };

        // 转16进制
        var Str2Bytes = function(str) {
            var pos = 0;
            var len = str.length;
            if (len % 2 != 0) {
                return null;
            }
            len /= 2;
            var hexA = new Array();
            for (var i = 0; i < len; i++) {
                var s = str.substr(pos, 2);
                var v = parseInt(s, 16);
                hexA.push(v);
                pos += 2;
            }
            return hexA[0];
        };

        // 开始考试
        var examUI = function(obj) {
            var examContent = document.getElementById("examContent");
            examContent.innerHTML = "";

            var body = document.createElement("div");
            body.className = "body";
            examContent.appendChild(body);

            //for shandy
            var header = document.createElement("div");
            header.className = 'header';
            body.appendChild(header);

            var examNum = document.createElement("div");
            examNum.className = 'examNum';
            body.appendChild(examNum);
            //end
            var answer_sheet = document.createElement("div");
            answer_sheet.className = "answer_sheet";
            body.appendChild(answer_sheet);

            var content = document.createElement("div");
            content.className = "content";
            body.appendChild(content);

            if (instance.duration !== 0) {
                var count_down = document.createElement("div");
                count_down.className = "count_down";
                body.appendChild(count_down);
                var count_down_content = document.createElement("div");
                count_down_content.className = "count_down_content";
                count_down.appendChild(count_down_content);
                var icon = document.createElement("i");
                icon.className = "icon";
                count_down_content.appendChild(icon);
                var time = document.createElement("span");
                time.id = "count_down";
                count_down_content.appendChild(time);

                var c = instance.duration;
                var examTime = localStorage.getItem("examTime");
                if (examTime === null) {
                    var exam = {};
                    if (exam.id === undefined) {
                        exam.id = instance.examID;
                    }
                    if (exam.duration === undefined) {
                        exam.duration = instance.duration;
                    }
                    localStorage.setItem("examTime", JSON.stringify(exam));
                } else {
                    var e = eval("(" + examTime + ")");
                    if (e.id === instance.examID) {
                        c = parseInt(e.duration);
                    } else {
                        e.id === instance.examID;
                        e.duration = instance.duration;
                        localStorage.setItem("examTime", JSON.stringify(e));
                    }
                }
                var s = (c % 60) < 10 ? ('0' + c % 60) : c % 60;
                var h = c / 3600 < 10 ? ('0' + parseInt(c / 3600)) : parseInt(c / 3600);
                var m = (c - h * 3600) / 60 < 10 ? ('0' + parseInt((c - h * 3600) / 60)) : parseInt((c - h * 3600) / 60);
                time.innerText = h + ':' + m + ':' + s;


                var de = eval("(" + localStorage.getItem("examTime") + ")");
                var t = parseInt(de.duration);

                window.int = instance.int = setInterval(function() {
                    t--;
                    var s = (t % 60) < 10 ? ('0' + t % 60) : t % 60;
                    var h = t / 3600 < 10 ? ('0' + parseInt(t / 3600)) : parseInt(t / 3600);
                    var m = (t - h * 3600) / 60 < 10 ? ('0' + parseInt((t - h * 3600) / 60)) : parseInt((t - h * 3600) / 60);
                    time.innerText = h + ':' + m + ':' + s;

                    var dexam = {};
                    if (dexam.id === undefined) {
                        dexam.id = instance.examID;
                    }
                    if (dexam.duration === undefined) {
                        dexam.duration = t;
                    }
                    // localStorage.setItem("examTime", JSON.stringify(dexam));

                    if (t < 0) {
                        clearInterval(window.int);
                        $(".timeup_submit_modal").addClass("is_visible");
                        $(".timeup_submit_modal .submit").unbind('click');
                        $(".timeup_submit_modal .submit").click(function() {
                            $(".timeup_submit_modal").removeClass("is_visible");
                            // 提交答案
                            postAnswer();
                        });
                    }
                }, 1000);
            }

            answerSheet(obj, content, answer_sheet, header, examNum, 0);
            questionUI(obj, content, answer_sheet, header, examNum, 0);
        };

        // 答案
        var addAnswer = function(id, data, obj, qn) {

            var l = window.localStorage.getItem("userAnswer");
            var sa = eval("(" + l + ")");

            if ((sa !== null) && (sa[instance.examID] !== undefined)) {

                var localStorageAnswer = 0;
                for (var i = 0; i < data.length; i++) {
                    if (data[i].className === "active") {
                        localStorageAnswer |= (0x01 << i);
                    }
                }
                var a = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f"];
                var s = "";
                var c = (localStorageAnswer & 0xF0) >> 4;
                s += a[c];
                c = localStorageAnswer & 0x0F;
                s += a[c];

                sa[instance.examID].splice((id - 1), 1, s);
                instance.storageDate[instance.examID] = sa[instance.examID];
                localStorage.setItem("userAnswer", JSON.stringify(instance.storageDate));
            }

            if (instance.answerObj[obj[qn]].choice !== undefined) {
                instance.answerObj[obj[qn]].userAnswer = 0;
                for (var i = 0; i < data.length; i++) {
                    if (data[i].className === "active") {

                        instance.answerObj[obj[qn]].userAnswer |= (0x01 << i);
                    }
                }
            } else {
                for (var i = 0; i < instance.answerObj[obj[qn]].question.length; i++) {
                    if (instance.answerObj[obj[qn]].question[i].id === id) {
                        instance.answerObj[obj[qn]].question[i].userAnswer = 0;
                        for (var j = 0; j < data.length; j++) {
                            if (data[j].className === "active") {
                                instance.answerObj[obj[qn]].question[i].userAnswer |= (0x01 << j);
                            }
                        }
                    }
                }
            }
        };
        // 答题卡
        var answerSheet = function(obj, content, answer_sheet, header, examNum, QN) {
            answer_sheet.innerHTML = "";
            //shandy
            if (header)
                header.innerHTML = "";
            //end

            var div = document.createElement("div");
            div.className = "answer_sheet_text";
            var span = document.createElement("span");
            span.innerText = "答题卡";
            div.appendChild(span);
            //for shandygaff
            div.onclick = function() {
                if ($('.answer_sheet').css('display') == 'none') {
                    $('.answer_sheet').css('display', 'block');
                    $('.answer_sheet_content').animate({
                        'bottom': 0
                    }, 'fast');
                } else {
                    $('.answer_sheet').css('display', 'none');
                    $('.answer_sheet_content').animate({
                        'bottom': '-100%'
                    }, 'fast');
                }
            };
            if (header)
                header.appendChild(div);
            //end
            // var icon = document.createElement("i");
            // div.appendChild(icon);
            // answer_sheet.appendChild(div);


            var answer_sheet_content = document.createElement("div");
            answer_sheet_content.className = "answer_sheet_content";
            answer_sheet.appendChild(answer_sheet_content);

            div = document.createElement("div");
            div.className = "answer_sheet_num";
            answer_sheet_content.appendChild(div);


            var ul = document.createElement("ul");
            // var la = eval("(" + window.localStorage.getItem("userAnswer") + ")");
            for (var i = 0; i < obj.length; i++) {
                var li = document.createElement("li");
                li.innerText = (i + 1);

                li.onclick = (function(i) {
                    return function() {
                        span.innerText = "答题卡";
                        changeAnswerSheet();
                        questionUI(obj, content, answer_sheet, header, examNum, i);
                        $(this).addClass('click').siblings('.click').removeClass('click');
                        //for shandygaff
                        // $('.exam_box').css('overflow-y','auto');
                        // $('.answer_sheet').animate({'bottom':'-100%'});
                        $('.answer_sheet').hide();
                        $('.answer_sheet_content').animate({
                            'bottom': 0
                        }, 'fast');
                        //end
                    }
                })(i);
                ul.appendChild(li);
                if (i === QN) {
                    li.className = "click";
                }

                if (instance.answerObj[obj[i]].choice !== undefined) {
                    var id = instance.answerObj[obj[i]].id;
                    var type = instance.answerObj[obj[i]].type;

                    if ((type !== 4) && (type !== 6)) {
                        if (instance.answerObj[obj[i]].userAnswer !== 0) {
                            li.className = "active";
                        }
                        if (i === QN) {
                            if (instance.answerObj[obj[QN]].userAnswer !== 0) {
                                li.className = "active";
                            }
                        }
                    } else {
                        var isHave = getSubjectiveAnswer(id);
                        if (isHave.length !== 0) {
                            li.className = "active";
                        }
                    }
                } else {
                    for (var j = 0; j < instance.answerObj[obj[i]].question.length; j++) {
                        var flag = true;
                        var id = instance.answerObj[obj[i]].question[j].id;
                        var type = instance.answerObj[obj[i]].question[j].type;

                        if ((type !== 4) && (type !== 6)) {
                            if (instance.answerObj[obj[i]].question[j].userAnswer !== 0) {
                                flag = false;
                                break;
                            }
                        } else {
                            var isHave = getSubjectiveAnswer(id);
                            if (isHave.length !== 0) {
                                flag = false;
                                break;
                            }
                        }
                    }
                    if (flag === false) {
                        li.className = "active";
                    }
                    if (i === QN) {
                        if (flag === false) {
                            li.className = "active";
                        }
                    }
                }

                // var l = localStorage.getItem("userAnswer");
                // var sa =  eval("("+ l +")");
                // console.log(sa);
                // if (sa !== null) {
                // 	for( var j = 0;j < sa[instance.examID].length;j++ ){
                //        if ( Number(j)=== Number(obj[i])  ) {
                //        	if( sa[instance.examID][j] !== "00"  ){
                //                li.className = "active";
                //            }
                //        }
                // 	}
                // }

            }
            div.appendChild(ul);

            div = document.createElement("div");
            div.className = "answer_sheet_remind";
            var ul = document.createElement("ul");
            var li = document.createElement("li");
            li.className = "blue_bg";
            ul.appendChild(li);

            li = document.createElement("li");
            li.innerText = "已作答";
            ul.appendChild(li);

            li = document.createElement("li");
            li.className = "white_bg";
            ul.appendChild(li);

            li = document.createElement("li");
            li.innerText = "未作答";
            ul.appendChild(li);
            div.appendChild(ul);
            answer_sheet_content.appendChild(div);

            // icon.onclick = function(){
            // 	$(this).toggleClass("active");
            // 	$(this).parent().next().slideToggle("fast");
            // };
        };

        var changeAnswerSheet = function() {
            if (instance.currentQuestion.choice !== undefined) {
                var type = instance.currentQuestion.type;
                var id = instance.currentQuestion.id;
                if ((type === 4) || (type === 6)) {
                    var isHave = getSubjectiveAnswer(id);
                    if (isHave.length !== 0) {
                        // 发送主观题答案
                        if (instance.user < 1000000000) {
                            postSubjectAnswer(id, isHave,
                                function(resp) {}
                            );
                        }
                    }
                }
            } else {
                var type = instance.currentSynthesisQuestion.type;
                var id = instance.currentSynthesisQuestion.id;
                if ((type === 4) || (type === 6)) {
                    var isHave = getSubjectiveAnswer(id);
                    if (isHave.length !== 0) {
                        if (instance.userid < 1000000000) {
                            // 发送主观题答案
                            postSubjectAnswer(id, isHave,
                                function(resp) {}
                            );
                        }
                    }
                }
            }
        };
        // 题目
        var questionUI = function(obj, content, answer_sheet, header, examNum, QN) {
            if (obj.result !== null) {

                var qn = QN;
                var questionContent = instance.answerObj[obj[qn]];
                instance.currentQuestion = questionContent;
                if (questionContent.choice !== undefined) {
                    var choice = questionContent.choice.split("\\n");
                }
                var id = questionContent.id;

                content.innerHTML = "";

                var examHeader = document.createElement("div");
                examHeader.className = "examHeader";
                content.appendChild(examHeader);

                //for shandy
                if (header)
                    examNum.innerHTML = '';
                //end
                var p = document.createElement("p");
                p.className = "num";
                p.innerText = "第" + (qn + 1) + "题 (多选题)";

                if (questionContent.choice !== undefined) {
                    var type = questionContent.type;
                    if ((type !== 4) && (type !== 6)) {
                        var a = questionContent.answer.split("");
                        var c = 0;
                        for (var i = 0; i < a.length; i++) {
                            if (parseInt(a[i]) === 1) {
                                c++;
                            }
                        }
                    }

                    switch (type) {
                        case 1:
                            p.innerText = "第" + (qn + 1) + "题 (单选题)";
                            break;
                        case 2:
                            p.innerText = "第" + (qn + 1) + "题 (多选题)";
                            break;
                        case 3:
                            p.innerText = "第" + (qn + 1) + "题 (判断题)";
                            break;
                        case 4:
                            p.innerText = "第" + (qn + 1) + "题 (填空题)";
                            break;
                        case 6:
                            p.innerText = "第" + (qn + 1) + "题 (解答题)";
                            break;
                        case 7:
                            p.innerText = "第" + (qn + 1) + "题 (不定项选择题)";
                            break;
                    }
                } else {
                    p.innerText = "第" + (qn + 1) + "题 (综合题)";
                }
                // examHeader.appendChild(p);
                //for shandy
                if (header)
                    examNum.appendChild(p);
                //end
                var title = document.createElement("div");
                title.className = "title";
                examHeader.appendChild(title);

                // 题干
                var bodyData = questionContent.body.split("\\n");
                showParagraph(bodyData, title);
                // for (var i = 0; i < bodyData.length; i++) {
                //     p = document.createElement("p");
                //     if (checkContent(bodyData[i])) {
                //         var img = document.createElement("img");
                //         img.src = bodyData[i];
                //         bindImageSwape(img);
                //         p.appendChild(img);

                //     } else {
                //         p.innerText = bodyData[i];
                //     }
                //     title.appendChild(p);
                // }

                // 综合题
                if (questionContent.choice === undefined) {
                    var littleQuestion = document.createElement("ul");
                    littleQuestion.className = "littleQuestion";
                    content.appendChild(littleQuestion);



                    var examBody = document.createElement("div");
                    examBody.className = "examBody";
                    content.appendChild(examBody);


                    for (var i = 0; i < questionContent.question.length; i++) {
                        var li = document.createElement("li");
                        li.innerText = (i + 1);
                        littleQuestion.appendChild(li);
                        li.onclick = (function(content, answer_sheet, examBody, obj, questionContent, qn, i) {
                            return function() {
                                var type = instance.currentSynthesisQuestion.type;
                                var id = instance.currentSynthesisQuestion.id;

                                if ((type !== 4) && (type !== 6)) {
                                    synthesisUI(content, answer_sheet, examBody, obj, questionContent, qn, i);
                                } else {
                                    var isHave = getSubjectiveAnswer(id);
                                    if (isHave.length !== 0) {
                                        if (instance.userid < 1000000000) {
                                            // 发送主观题答案
                                            postSubjectAnswer(id, isHave,
                                                function(o) {
                                                    // var o = eval( "(" + resp.responseText + ")" );
                                                    if (o.status === 0) {
                                                        synthesisUI(content, answer_sheet, examBody, obj, questionContent, qn, i);
                                                    }
                                                }
                                            );
                                        } else {
                                            synthesisUI(content, answer_sheet, examBody, obj, questionContent, qn, i);
                                        }

                                    } else {
                                        synthesisUI(content, answer_sheet, examBody, obj, questionContent, qn, i);
                                    }
                                }
                                $(this).addClass('click').siblings('.click').removeClass('click');
                            }
                        })(content, answer_sheet, examBody, obj, questionContent, qn, i);
                        if (i === 0) {
                            li.className = "click";
                        }
                    }
                    synthesisUI(content, answer_sheet, examBody, obj, questionContent, qn, 0);
                } else { // 非综合题
                    var examBody = document.createElement("ul");
                    examBody.className = "examBody";
                    content.appendChild(examBody);
                    var isEmpty = true;
                    for (var i = 0; i < choice.length; i++) {
                        if (choice[i] !== "") {
                            isEmpty = false;
                            break;
                        }
                    }
                    if ((choice.length !== 2) && (isEmpty === false)) {
                        for (var i = 0; i < choice.length; i++) {
                            var li = document.createElement("li");

                            var span = document.createElement("span");
                            span.className = "choice";
                            span.innerText = String.fromCharCode(65 + i) + ". " + choice[i];
                            li.appendChild(span);

                            examBody.appendChild(li);
                        }
                    } else if ((choice.length === 2) && (isEmpty === false)) {

                    } else {
                        var editorContainer = document.createElement("div");
                        editorContainer.className = "editorContainer";
                        examBody.appendChild(editorContainer);

                        var isHave = getSubjectiveAnswer(id);
                        if (isHave.length !== 0) {
                            // 显示初始答案
                            var c = document.createElement("div");
                            c.className = "editContent";
                            editorContainer.appendChild(c);

                            EditViewer.createNew(c).render(isHave);
                        }
                        var E = window.wangEditor;
                        var editor = new E(editorContainer);
                        editor.create();

                        editorContainer.onkeyup = function() {
                            var s = editor.txt.submit();
                            if (s.length !== 0) {
                                if (instance.subjective[instance.examID] === undefined) {
                                    instance.subjective[instance.examID] = {};
                                }
                                instance.subjective[instance.examID][id] = encodeURIComponent(LZString.compressToBase64(s));
                                localStorage.setItem("subjective", JSON.stringify(instance.subjective));
                            }
                        };
                    }
                }

                var examFooter = document.createElement("div");
                examFooter.className = "examFooter";
                content.appendChild(examFooter);
                //for shandy
                // document.getElementsByClassName('body')[0].appendChild(examFooter);
                //end
                // 上一题
                if (qn !== 0) {
                    var pre = document.createElement("a");
                    pre.className = "pre";
                    pre.innerHTML = "<i></i>";
                    examFooter.appendChild(pre);
                    pre.onclick = function() {
                        answerSheet(obj, content, answer_sheet, header, examNum, qn - 1);
                        questionUI(obj, content, answer_sheet, header, examNum, qn - 1);
                    };
                }

                // 选项
                var choice_content = document.createElement("ul");
                choice_content.className = "choice_content";
                examFooter.appendChild(choice_content);

                // var la = eval("("+ window.localStorage.getItem("userAnswer") + ")");

                if (questionContent.choice !== undefined) {
                    if (isEmpty === false) {
                        if (choice.length !== 2) {
                            for (var i = 0; i < choice.length; i++) {
                                var li = document.createElement("li");

                                li.innerText = String.fromCharCode(65 + i);
                                choice_content.appendChild(li);

                                if (c < 2) {
                                    li.onclick = (function(id) {
                                        return function() {
                                            $(this).addClass('active').siblings('.active').removeClass('active');


                                            var data = $(".choice_content li");
                                            var answer = addAnswer(id, data, obj, qn);

                                            answerSheet(obj, content, answer_sheet, header, examNum, qn);
                                        }
                                    })(id);
                                } else {
                                    li.onclick = (function(id) {
                                        return function() {
                                            $(this).toggleClass('active');
                                            var data = $(".choice_content li");
                                            var answer = addAnswer(id, data, obj, qn);
                                            answerSheet(obj, content, answer_sheet, header, examNum, qn);
                                        }
                                    })(id);
                                }
                            }

                        } else if (choice.length === 2) {
                            var li = document.createElement("li");
                            li.innerText = "对";
                            li.onclick = (function(id) {
                                return function() {
                                    $(this).addClass('active').siblings('.active').removeClass('active');
                                    var data = $(".choice_content li");
                                    var answer = addAnswer(id, data, obj, qn);
                                    answerSheet(obj, content, answer_sheet, header, examNum, qn);
                                }
                            })(id);
                            choice_content.appendChild(li);

                            var li = document.createElement("li");
                            li.innerText = "错";
                            li.onclick = (function(id) {
                                return function() {
                                    $(this).addClass('active').siblings('.active').removeClass('active');
                                    var data = $(".choice_content li");
                                    var answer = addAnswer(id, data, obj, qn);
                                    answerSheet(obj, content, answer_sheet, header, examNum, qn);
                                }
                            })(id);
                            choice_content.appendChild(li);
                        }
                        var w = 40 * choice.length + 5 * (choice.length - 1);
                        choice_content.style.marginLeft = (0 - w / 2) + "px";

                        if (questionContent.userAnswer !== 0) {
                            // 最后一位为1
                            var a = 0x01;
                            for (var j = 0; j < choice.length; j++) {
                                if ((questionContent.userAnswer & a) === a) {
                                    // 每次取一位
                                    $(".choice_content li")[j].className = "active";
                                }
                                a <<= 1; // 把1向左移一位
                            }
                        }
                    }
                }

                // 下一题
                var next = document.createElement("a");
                next.className = "next";
                next.innerHTML = "<i></i>";
                examFooter.appendChild(next);
                next.onclick = function() {
                    // answerSheet(obj,content,answer_sheet,qn+1);
                    // questionUI(obj, content, answer_sheet,qn+1);

                    if (instance.currentQuestion.choice !== undefined) {
                        var type = instance.currentQuestion.type;
                        if ((type !== 4) && (type !== 6)) {
                            answerSheet(obj, content, answer_sheet, header, examNum, qn + 1);
                            questionUI(obj, content, answer_sheet, header, examNum, qn + 1);
                        } else {
                            var isHave = getSubjectiveAnswer(instance.currentQuestion.id);
                            if (isHave.length !== 0) {
                                if (instance.userid < 1000000000) {
                                    // 发送主观题答案
                                    postSubjectAnswer(instance.currentQuestion.id, isHave,
                                        (function(obj, content, answer_sheet, qn) {
                                            return function(o) {
                                                // var o = eval( "(" + resp.responseText + ")" );
                                                if (o.status === 0) {
                                                    answerSheet(obj, content, answer_sheet, header, examNum, qn);
                                                    questionUI(obj, content, answer_sheet, header, examNum, qn);
                                                }
                                            }
                                        })(obj, content, answer_sheet, qn + 1)
                                    );
                                } else {
                                    answerSheet(obj, content, answer_sheet, header, examNum, qn + 1);
                                    questionUI(obj, content, answer_sheet, header, examNum, qn + 1);
                                }
                            } else {
                                answerSheet(obj, content, answer_sheet, header, examNum, qn + 1);
                                questionUI(obj, content, answer_sheet, header, examNum, qn + 1);
                            }
                        }
                    } else {
                        var type = instance.currentSynthesisQuestion.type;
                        var id = instance.currentSynthesisQuestion.id;
                        if ((type !== 4) && (type !== 6)) {
                            answerSheet(obj, content, answer_sheet, header, examNum, qn + 1);
                            questionUI(obj, content, answer_sheet, header, examNum, qn + 1);
                        } else {
                            var isHave = getSubjectiveAnswer(id);
                            if (isHave.length !== 0) {
                                if (instance.uderid < 1000000000) {
                                    // 发送主观题答案
                                    postSubjectAnswer(id, isHave,
                                        function(o) {
                                            // var o = eval( "(" + resp.responseText + ")" );
                                            if (o.status === 0) {
                                                answerSheet(obj, content, answer_sheet, header, examNum, qn + 1);
                                                questionUI(obj, content, answer_sheet, header, examNum, qn + 1);
                                            }
                                        }
                                    );
                                } else {
                                    answerSheet(obj, content, answer_sheet, header, examNum, qn + 1);
                                    questionUI(obj, content, answer_sheet, header, examNum, qn + 1);
                                }
                            } else {
                                answerSheet(obj, content, answer_sheet, header, examNum, qn + 1);
                                questionUI(obj, content, answer_sheet, header, examNum, qn + 1);
                            }
                        }
                    }
                };


                // 完成
                if (qn === (obj.length - 1)) {
                    // next.style.display = "none";
                    next.innerText = "完成";
                    next.className = 'next finish';
                    // if (obj.type === "preExam") {
                    next.onclick = function(e) {
                        changeAnswerSheet();
                        e.stopPropagation();
                        $(".submit_paper_modal").addClass("is_visible");
                        var number = 0;
                        for (var i = 0; i < obj.length; i++) {
                            if (instance.answerObj[obj[i]].userAnswer !== undefined) {
                                if ((instance.answerObj[obj[i]].type !== 4) && (instance.answerObj[obj[i]].type !== 6)) {
                                    if (instance.answerObj[obj[i]].userAnswer !== 0) {
                                        number++;
                                    }
                                } else {
                                    var isHave = getSubjectiveAnswer(instance.answerObj[obj[i]].id);
                                    if (isHave.length !== 0) {
                                        number++;
                                    }
                                }
                            } else {
                                var isTrue = false;
                                for (var j = 0; j < instance.answerObj[obj[i]].question.length; j++) {
                                    var type = instance.answerObj[obj[i]].question[j].type;
                                    if ((type !== 4) && (type !== 6)) {
                                        if (instance.answerObj[obj[i]].question[j].userAnswer !== 0) {
                                            isTrue = true;
                                            break;
                                        }
                                    } else {
                                        var isHave = getSubjectiveAnswer(instance.answerObj[obj[i]].question[j].id);
                                        if (isHave.length !== 0) {
                                            isTrue = true;
                                        }
                                    }
                                }
                                if (isTrue === true) {
                                    number++;
                                }
                            }
                        }

                        if (number !== obj.length) {
                            $(".prompt_message").text("还有" + (obj.length - number) + "道没做哦～");
                        } else {
                            $(".prompt_message").text("要不要检查一遍再交卷呢？");
                        }
                    };
                    $(".submit_paper_modal .check").on("click", function() {
                        $(".submit_paper_modal").removeClass("is_visible");
                    });
                    $(".submit_paper_modal .submit").unbind("click");
                    $(".submit_paper_modal .submit").click(function() {
                        // instance.showAnswerUI();
                        // meetingAnswer(id);
                        $(".t_news").css("display", "none");
                        postAnswer();
                    });

                }
            }
        };

        // 综合题UI
        var synthesisUI = function(content, answer_sheet, examBody, obj, synthesisObj, qn, q) {
            examBody.innerHTML = "";
            instance.currentSynthesisQuestion = synthesisObj.question[q];
            var id = synthesisObj.question[q].id;
            var type = synthesisObj.question[q].type;
            if ((type !== 4) && (type !== 6)) {
                var a = synthesisObj.question[q].answer.split("");
                var c = 0;
                for (var i = 0; i < a.length; i++) {
                    if (parseInt(a[i]) === 1) {
                        c++;
                    }
                }
            }

            var littleQuestionTitle = document.createElement("div");
            littleQuestionTitle.className = "littleQuestionTitle";
            examBody.appendChild(littleQuestionTitle);

            // 小题干
            var bodyData = synthesisObj.question[q].body.split("\\n");
            showParagraph(bodyData, littleQuestionTitle);
            // for (var i = 0; i < bodyData.length; i++) {
            //     p = document.createElement("p");
            //     if (checkContent(bodyData[i])) {
            //         var img = document.createElement("img");
            //         img.src = bodyData[i];
            //         bindImageSwape(img);
            //         p.appendChild(img);
            //     } else {
            //         p.innerText = bodyData[i];
            //     }
            //     littleQuestionTitle.appendChild(p);
            // }

            var littleQuestionChoice = document.createElement("ul");
            littleQuestionChoice.className = "littleQuestionChoice";
            examBody.appendChild(littleQuestionChoice);

            // 选项
            var choice = synthesisObj.question[q].choice.split("\\n");
            var isEmpty = true;
            for (var i = 0; i < choice.length; i++) {
                if (choice[i] !== "") {
                    isEmpty = false;
                    break;
                }
            }
            if ((choice.length !== 2) && (isEmpty === false)) {
                for (var i = 0; i < choice.length; i++) {
                    var li = document.createElement("li");

                    var span = document.createElement("span");
                    span.className = "choice";
                    span.innerText = String.fromCharCode(65 + i) + ". " + choice[i];
                    li.appendChild(span);

                    littleQuestionChoice.appendChild(li);
                }
            } else {
                var editorContainer = document.createElement("div");
                editorContainer.className = "editorContainer";
                examBody.appendChild(editorContainer);

                var isHave = getSubjectiveAnswer(id);
                if (isHave.length !== 0) {
                    // 显示初始答案
                    var c = document.createElement("div");
                    c.className = "editContent";
                    editorContainer.appendChild(c);

                    EditViewer.createNew(c).render(isHave);
                }

                var E = window.wangEditor;
                var editor = new E(editorContainer);
                editor.create();

                editorContainer.onkeyup = function() {
                    var s = editor.txt.submit();
                    if (s.length !== 0) {
                        if (instance.subjective[instance.examID] === undefined) {
                            instance.subjective[instance.examID] = {};
                        }
                        instance.subjective[instance.examID][id] = encodeURIComponent(LZString.compressToBase64(s));;
                        localStorage.setItem("subjective", JSON.stringify(instance.subjective));
                    }
                };
            }

            // 选择按钮
            var littleQuestionChoiceContent = document.createElement("ul");
            littleQuestionChoiceContent.className = "littleQuestionChoiceContent";
            examBody.appendChild(littleQuestionChoiceContent);

            if (isEmpty === false) {
                if (choice.length !== 2) {
                    for (var i = 0; i < choice.length; i++) {
                        var li = document.createElement("li");

                        li.innerText = String.fromCharCode(65 + i);
                        littleQuestionChoiceContent.appendChild(li);

                        if (c < 2) {
                            li.onclick = (function(i, id) {
                                return function() {
                                    $(this).addClass('active').siblings('.active').removeClass('active');
                                    // var id = synthesisObj.question[q].id;
                                    var data = $(".littleQuestionChoiceContent li");
                                    var answer = addAnswer(id, data, obj, qn);
                                    answerSheet(obj, content, answer_sheet, null, null, qn);
                                }
                            })(i, id);
                        } else {
                            li.onclick = (function(i, id) {
                                return function() {
                                    $(this).toggleClass('active');
                                    // var id = synthesisObj.question[q].id;
                                    var data = $(".littleQuestionChoiceContent li");
                                    var answer = addAnswer(id, data, obj, qn);

                                    answerSheet(obj, content, answer_sheet, null, null, qn);
                                }
                            })(i, id);
                        }
                    }
                } else if (choice.length === 2) {
                    var li = document.createElement("li");
                    li.innerText = "对";
                    li.onclick = function() {
                        $(this).addClass('active').siblings('.active').removeClass('active');
                        var data = $(".littleQuestionChoiceContent li");
                        var answer = addAnswer(data, obj, qn);
                        answerSheet(obj, content, answer_sheet, null, null, qn);
                    };
                    littleQuestionChoiceContent.appendChild(li);

                    var li = document.createElement("li");
                    li.innerText = "错";
                    li.onclick = function() {
                        $(this).addClass('active').siblings('.active').removeClass('active');
                        var data = $(".littleQuestionChoiceContent li");
                        var answer = addAnswer(data, obj, qn);
                        answerSheet(obj, content, answer_sheet, null, null, qn);
                    };
                    littleQuestionChoiceContent.appendChild(li);
                }
                if (synthesisObj.question[q].userAnswer !== 0) {
                    // 最后一位为1
                    var a = 0x01;

                    for (var j = 0; j < choice.length; j++) {
                        if ((synthesisObj.question[q].userAnswer & a) === a) { // 每次取一位

                            $(".littleQuestionChoiceContent li")[j].className = "active";
                        }
                        a <<= 1; // 把1向左移一位
                    }
                }
            }

        };
        // 处理客观题答案
        var handleLocalAnswer = function(){
            var arr = eval("(" + localStorage.getItem("userAnswer") + ")")[instance.examID];

            for (var k in instance.answerObj) {
                var q = instance.answerObj[k];
                if (q.choice !== undefined) {
                    if ((q.type === 4) || (q.type === 6)) {
                        delete arr[q.id - 1];
                    }
                } else {
                    for (var j = 0; j < q.question.length; j++) {
                        if ((q.question[j].type === 4) || (q.question[j].type === 6)) {
                            delete arr[q.question[j].id - 1];
                        }
                    }
                }
            }

            var s = arr.join("");

            return s;
        };

        var handleUserAnswerToNum = function(str){
            // var f = o[k].question[i].answer;
            var r = 0x00;
            for (var j = 0; j < str.length; j++) {
                if (str[j] === "1") {
                    r |= (0x01 << j);
                    // o[k].question[i].answer = r;
                    return r;
                }
            }
        };

        // 提交答案
        var postAnswer = function() {
            clearInterval(window.int);
            var o = instance.answerObj;
            // var a = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f"];
            // var s = "";
            // var str = [];
            // for (var i = 0; i < instance.originalQuestion.count; i++) {
            //     str.push(0);
            // }
            // for (var k in o) {
            //     if (o[k].choice !== undefined) {
            //         if ((o[k].type !== 4) && (o[k].type !== 6)) {
            //             var b = o[k].userAnswer;
            //             var d = o[k].id;
            //             str[d - 1] = b;
            //             var f = o[k].answer;
            //             var r = 0x00;
            //             for (var i = 0; i < f.length; i++) {
            //                 if (f[i] === "1") {
            //                     r |= (0x01 << i);
            //                     o[k].answer = r;
            //                 }
            //             }
            //         } else {
            //             o[k].userAnswer = "";
            //             var isHave = getSubjectiveAnswer(o[k].id);
            //             if (isHave.length !== 0) {
            //                 o[k].userAnswer = isHave;
            //             }
            //         }
            //     } else {
            //         for (var i = 0; i < o[k].question.length; i++) {
            //             if ((o[k].question[i].type !== 4) && (o[k].question[i].type !== 6)) {
            //                 var b = o[k].question[i].userAnswer;
            //                 var d = o[k].question[i].id;
            //                 str[d - 1] = b;
            //                 var f = o[k].question[i].answer;
            //                 var r = 0x00;
            //                 for (var j = 0; j < f.length; j++) {
            //                     if (f[j] === "1") {
            //                         r |= (0x01 << j);
            //                         o[k].question[i].answer = r;
            //                     }
            //                 }
            //             } else {
            //                 o[k].question[i].userAnswer = "";
            //                 var isHave = getSubjectiveAnswer(o[k].question[i].id);
            //                 if (isHave.length !== 0) {
            //                     o[k].question[i].userAnswer = isHave;
            //                 }
            //             }
            //         }
            //     }
            // }
            // for (var i = 0; i < str.length; i++) {
            //     // 字节 转 16进制
            //     var c = (str[i] & 0xF0) >> 4;
            //     s += a[c];
            //     c = str[i] & 0x0F;
            //     s += a[c];
            // }
            // var newArr = [];
            // for (var i = 0; i < s.length; i += 2) {
            //     newArr.push(s.substring(i, i + 2));
            // }
            // for (var k in instance.answerObj) {
            //     if (instance.answerObj[k].choice !== undefined) {
            //         if ((instance.answerObj[k].type === 4) || (instance.answerObj[k].type === 6)) {
            //             delete newArr[instance.answerObj[k].id - 1];
            //         }
            //     } else {
            //         for (var j = 0; j < instance.answerObj[k].question.length; j++) {
            //             if ((instance.answerObj[k].question[j].type === 4) || (instance.answerObj[k].question[j].type === 6)) {
            //                 delete newArr[instance.answerObj[k].question[j].id - 1];
            //             }
            //         }
            //     }
            // }
            //
            // s = newArr.join("");
            var s = handleLocalAnswer();
            if (instance.userid > 1000000000) {
                showPersonalScore(o, false);
                //for shandygaff
                showAnswerUI(o, false);
                //end
                return;
            }

            if(instance.flag&&!instance.isRedo){
                // console.log(s);
                space.answerExam(instance.meetingID, instance.examID, s, function(obj) {
                    // var obj = eval("(" + response.responseText + ")");
                    if (obj.status === 0) {
                        $(".timeup_submit_modal .submit").unbind('click');
                        $(".submit_paper_modal").removeClass("is_visible");
                        tip("交卷成功");
                        showPersonalScore(o, false);
                        //for shandygaff
                        showAnswerUI(o, false);
                        //end
                        localStorage.setItem("isSubmit",true);
                    }else{
                        tip("试卷提交失败");
                    }
                });

            }else{
                $(".submit_paper_modal").removeClass("is_visible");
                showPersonalScore(o, false);
                //for shandygaff
                showAnswerUI(o, false);
                //end
            }

        };

        // 显示个人成绩
        var showPersonalScore = function(o, show) {
            var allRate = 0;
            for (var i = 0; i < instance.originalQuestion.subject.length; i++) {
                var c = 0;
                for (var j = 0; j < instance.originalQuestion.subject[i].question.length; j++) {
                    if (instance.originalQuestion.subject[i].question[j].choice !== undefined) {

                        var id = instance.originalQuestion.subject[i].question[j].id;
                        var type = instance.originalQuestion.subject[i].question[j].type;
                        if ((type !== 4) && (type !== 6)) {
                            if (o[id].userAnswer === (o[id].answer.length?handleUserAnswerToNum(o[id].answer):o[id].answer)) {
                                c++;
                            }
                        }
                    } else {

                    }
                }
                if (instance.originalQuestion.subject[i].correctNum === undefined) {
                    instance.originalQuestion.subject[i].correctNum = c;
                }

                allRate += instance.originalQuestion.subject[i].correctNum;

            }
            if (instance.originalQuestion.rate === undefined) {
                instance.originalQuestion.rate = (allRate / instance.originalQuestion.count * 100).toFixed(1);
            }

            $("#examContent").css("display", "none");
            $(".exam_box").css("overflow", "hidden");
            $(".document-main-box").css("display", "block");
            $(".document-main-header").html("");
            $(".document-main-body").html("");



            if(instance.originalQuestion.rate>50){
                var b = '<div class="rate">' + '<span class="red"><em>' + instance.originalQuestion.rate + '%</em>' + '正确率</span>' + '<p class="msg2">好样的，测验完成！</p>' + '</div> ';
                $(".document-main-body").addClass("green");
            }else{
                var b = '<div class="rate">' + '<span class="red"><em>' + instance.originalQuestion.rate + '%</em>' + '正确率</span>' + '<p class="msg2">仔细检查错题，不能蒙混过关哦～</p>' + '</div> ';
                $(".document-main-body").removeClass("green");
            }
            $(".document-main-body").append(b);

            var d = '<p class="footer_2">' + '<span class="document-main-footer_2">查看试卷</span>' + '</p>';
            // $(".document-main-footer").append(d);

            $(".document-main-footer_2").on("click", function() {
                showAnswerUI(o, show);
            });

        };
        // 测验完成后显示答案
        var showAnswerUI = function(o, show) {
            if (show === false) {
                o = instance.answerObj;
            }
            var obj = [];

            for (var k in o) {
                obj.push(k);
            }
            $("#examContent").css("display", "block");
            // for shandygaff
            // $(".document-main-box").css("display","none");
            //end
            var examContent = document.getElementById("examContent");
            examContent.innerHTML = "";

            //for shandy
            var header = document.createElement("div");
            header.className = "answer_header";
            examContent.appendChild(header);

            var answer_list = document.createElement("div");
            answer_list.className = "answer_list";
            examContent.appendChild(answer_list);
            //end

            var answer_body = document.createElement("div");
            answer_body.className = "answer_body";
            examContent.appendChild(answer_body);

            var answer_sheet = document.createElement("div");
            answer_sheet.className = "answer_sheet";
            answer_list.appendChild(answer_sheet);

            var content = document.createElement("div");
            content.className = "content";
            answer_body.appendChild(content);

            var look_over = document.createElement("div");
            look_over.className = "look_over";
            look_over.innerText = "查看成绩";
            look_over.onclick = function() {
                showPersonalScore(o, show);
            };
            // answer_body.appendChild(look_over);

            viewAnswerSheet(obj, o, answer_sheet, content, header, 0);
            viewPaper(obj, o, answer_sheet, content, 0);
        };
        // -------查看答案-答题卡
        var viewAnswerSheet = function(obj, o, answer_sheet, content, header, QN) {

            answer_sheet.innerHTML = "";
            //for shandy
            if (header)
                header.innerHTML = "";
            //end

            var div = document.createElement("div");
            div.className = "answer_sheet_text";
            var span = document.createElement("span");
            span.innerText = "答题卡";
            div.appendChild(span);
            //for shandygaff
            div.onclick = function() {
                $('.answer_list').toggle();
                if ($('.answer_list').css('display') !== 'none') {
                    $('.answer_list').animate({
                        'top': '50px'
                    });
                } else {
                    // $('.answer_list').animate({'top':'-100%'});
                }
            };
            //end
            // var icon = document.createElement("i");
            // div.appendChild(icon);
            //for shandy
            if (header)
                header.appendChild(div);
            //end
            var answer_sheet_content = document.createElement("div");
            answer_sheet_content.className = "answer_sheet_content";
            answer_sheet.appendChild(answer_sheet_content);

            div = document.createElement("div");
            div.className = "answer_sheet_num";
            answer_sheet_content.appendChild(div);

            var ul = document.createElement("ul");
            for (var i = 0; i < obj.length; i++) {
                // var flag = true;
                var li = document.createElement("li");
                li.className = "true";
                li.innerText = (i + 1);

                li.onclick = (function(i) {
                    return function() {
                        span.innerText = "答题卡";

                        viewPaper(obj, o, answer_sheet, content, i);
                        //for shandygaff
                        $('.document-main-box').hide();
                        $('.exam_box').css('overflow', 'auto');
                        $('.answer_list').hide();
                        //end
                    }
                })(i);
                ul.appendChild(li);

                if (o[obj[i]].choice !== undefined) {
                    if (o[obj[i]].userAnswer !== (o[obj[i]].answer.length?handleUserAnswerToNum(o[obj[i]].answer):o[obj[i]].answer)) {
                        li.className = "false";
                    }
                } else {
                    var flag = true;
                    for (var j = 0; j < o[obj[i]].question.length; j++) {
                        if (o[obj[i]].question[j].userAnswer !== (o[obj[i]].question[j].answer.length? handleUserAnswerToNum(o[obj[i]].question[j].answer):o[obj[i]].question[j].answer)) {
                            flag = false;
                            break;
                        }
                    }

                    if (flag === false) {
                        li.className = "false";
                    }
                }
            }
            div.appendChild(ul);

            div = document.createElement("div");
            div.className = "answer_sheet_remind";
            var ul = document.createElement("ul");
            var li = document.createElement("li");
            li.className = "green_bg";
            ul.appendChild(li);

            li = document.createElement("li");
            li.innerText = "正确";
            ul.appendChild(li);

            li = document.createElement("li");
            li.className = "pink_bg";
            ul.appendChild(li);

            li = document.createElement("li");
            li.innerText = "错误";
            ul.appendChild(li);
            div.appendChild(ul);
            //for shandy
            // answer_sheet_content.appendChild(div);
            //end
            // icon.onclick = function(){
            // 	$(this).toggleClass("active");
            // 	$(this).parent().next().slideToggle("fast");
            // };
        };
        // -------查看答案-试卷
        var viewPaper = function(obj, o, answer_sheet, content, QN) {
            if (o.result !== null) {

                var qn = QN;
                var questionContent = o[obj[qn]];
                if (questionContent.choice !== undefined) {
                    var analysis = questionContent.analysis.split("\\n");
                    if ((questionContent.type !== 4) && (questionContent.type !== 6)) {
                        var choice = questionContent.choice.split("\\n");

                        var answer = questionContent.answer.length?questionContent.answer:handleAnswer(questionContent.answer,choice.length);
                        var userAnswer = handleAnswer(questionContent.userAnswer, choice.length);
                    } else {
                        var answer = questionContent.answer.split("\\n");
                    }
                }

                content.innerHTML = "";


                var examHeader = document.createElement("div");
                examHeader.className = "examHeader";
                content.appendChild(examHeader);

                //for shandy
                // var header = document.createElement("div");
                // header.className = "answer_header";
                // content.appendChild(header);

                //end


                var p = document.createElement("p");
                p.className = "num";
                p.innerText = "第" + (qn + 1) + "题 (多选题)";

                if (questionContent.choice !== undefined) {
                    var c = 0;
                    for (var i = 0; i < answer.length; i++) {
                        if (parseInt(answer[i]) === 1) {
                            c++;
                        }
                    }
                    if (questionContent.type === 1) {
                        p.innerText = "第" + (qn + 1) + "题 (单选题)";
                    } else if (questionContent.type === 2) {
                        p.innerText = "第" + (qn + 1) + "题 (多选题)";
                    } else if (questionContent.type === 3) {
                        p.innerText = "第" + (qn + 1) + "题 (判断题)";
                    } else if (questionContent.type === 4) {
                        p.innerText = "第" + (qn + 1) + "题 (填空题)";
                    } else if (questionContent.type === 6) {
                        p.innerText = "第" + (qn + 1) + "题 (解答题)";
                    } else if (questionContent.type === 7) {
                        p.innerText = "第" + (qn + 1) + "题 (不定项选择题)";
                    }
                } else {
                    p.innerText = "第" + (qn + 1) + "题 (综合题)";
                }
                examHeader.appendChild(p);

                var title = document.createElement("div");
                title.className = "title";
                examHeader.appendChild(title);

                // 题干
                var bodyData = questionContent.body.split("\\n");
                showParagraph(bodyData, title);
                // for (var i = 0; i < bodyData.length; i++) {
                //     p = document.createElement("p");
                //     if (checkContent(bodyData[i])) {
                //         var img = document.createElement("img");
                //         img.src = bodyData[i];
                //         bindImageSwape(img);
                //         p.appendChild(img);

                //     } else {
                //         p.innerText = bodyData[i];
                //     }
                //     title.appendChild(p);
                // }

                // 选项
                // 综合题
                if (questionContent.choice === undefined) {
                    var littleQuestion = document.createElement("ul");
                    littleQuestion.className = "littleQuestion";
                    content.appendChild(littleQuestion);



                    var examBody = document.createElement("div");
                    examBody.className = "examBody";
                    content.appendChild(examBody);


                    for (var i = 0; i < questionContent.question.length; i++) {
                        var li = document.createElement("li");
                        li.innerText = (i + 1);
                        littleQuestion.appendChild(li);
                        li.onclick = (function(content, answer_sheet, examBody, obj, questionContent, qn, i) {
                            return function() {
                                showSynthesisUI(content, answer_sheet, examBody, obj, questionContent, qn, i);
                                $(this).addClass('click').siblings('.click').removeClass('click');
                            }

                        })(content, answer_sheet, examBody, obj, questionContent, qn, i);
                        if (i === 0) {
                            li.className = "click";
                        }
                    }
                    showSynthesisUI(content, answer_sheet, examBody, obj, questionContent, qn, 0);
                } else { // 非综合题
                    var examBody = document.createElement("ul");
                    examBody.className = "examBody";
                    if ((questionContent.type !== 4) && (questionContent.type !== 6)) {
                        for (var i = 0; i < choice.length; i++) {
                            var li = document.createElement("li");

                            var span = document.createElement("span");
                            span.className = "choice";
                            span.innerText = String.fromCharCode(65 + i) + ". " + choice[i];
                            li.appendChild(span);

                            examBody.appendChild(li);
                        }
                    }
                    content.appendChild(examBody);
                }

                if (questionContent.choice !== undefined) {
                    // 正确答案
                    var examChoice = document.createElement("div");
                    examChoice.className = "examChoice";
                    content.appendChild(examChoice);

                    var examChoiceContent = document.createElement("div");
                    examChoiceContent.className = "examChoiceContent";
                    examChoice.appendChild(examChoiceContent);

                    var true_answer_content = document.createElement("div");
                    true_answer_content.className = "true_answer_content";
                    var span = document.createElement("span");
                    span.className = "text";
                    span.innerText = "正确答案：";
                    true_answer_content.appendChild(span);
                    examChoiceContent.appendChild(true_answer_content);

                    // 我的答案
                    var user_answer_content = document.createElement("div");
                    user_answer_content.className = "user_answer_content";
                    var span = document.createElement("span");
                    span.className = "text";
                    span.innerText = "我的答案：";
                    user_answer_content.appendChild(span);
                    examChoiceContent.appendChild(user_answer_content);

                    if ((questionContent.type !== 4) && (questionContent.type !== 6)) {
                        if (answer.length !== 2) {
                            for (var i = 0; i < answer.length; i++) {
                                if (parseInt(answer[i]) === 1) {
                                    var span = document.createElement("span");
                                    span.className = "true_answer";
                                    span.innerText = String.fromCharCode(65 + i);
                                    true_answer_content.appendChild(span);
                                }
                            }
                        } else {
                            for (var i = 0; i < answer.length; i++) {
                                if (parseInt(answer[i]) === 1) {
                                    var span = document.createElement("span");
                                    span.className = "true_answer";
                                    true_answer_content.appendChild(span);
                                    span.innerText = "对";
                                    if (String.fromCharCode(65 + i) === "B") {
                                        span.innerText = "错";
                                    }
                                }
                            }
                        }



                        // 判断是否做对
                        var c = true;
                        if (userAnswer.length === answer.length) {
                            for (var i = 0; i < userAnswer.length; i++) {
                                if (parseInt(userAnswer[i]) !== parseInt(answer[i])) {
                                    c = false;
                                    break;
                                }
                            }
                        } else {
                            c = false;
                        }

                        var flag = true;
                        for (var i = 0; i < userAnswer.length; i++) {
                            if (parseInt(userAnswer[i]) !== 0) {
                                flag = false;
                                break
                            }
                        }
                        if (flag === false) {
                            for (var j = 0; j < userAnswer.length; j++) {
                                if (parseInt(userAnswer[j]) === 1) {
                                    span = document.createElement("span");
                                    span.className = "user_answer";
                                    span.innerText = String.fromCharCode(65 + j);
                                    user_answer_content.appendChild(span);
                                    if (choice.length !== 2) {
                                        // p.innerText ="第" + (qn + 1) + "题 (单选题)";
                                        span.innerText = String.fromCharCode(65 + j);
                                    } else {
                                        // p.innerText ="第" + (qn + 1) + "题 (判断题)";
                                        if (String.fromCharCode(65 + j) === "B") {
                                            span.innerText = "错";
                                        } else if (String.fromCharCode(65 + j) === "A") {
                                            span.innerText = "对";
                                        }
                                    }
                                    if (c === false) {
                                        span.className += " false";
                                    } else {
                                        span.className += " true";
                                    }
                                }
                            }
                        } else {
                            var span = document.createElement("span");
                            span.className = "user_answer false";
                            span.innerText = "未作答";
                            user_answer_content.appendChild(span);
                        }
                    } else {
                        showParagraph(answer, true_answer_content, "trueAnswer");
                        // for (var i = 0; i < answer.length; i++) {
                        //     var p = document.createElement("p");
                        //     p.className = "trueAnswer";
                        //     if (checkContent(answer[i])) {
                        //         var img = document.createElement("img");
                        //         img.src = answer[i];
                        //         bindImageSwape(img);
                        //         p.appendChild(img);
                        //     } else {
                        //         p.innerText = answer[i];
                        //     }
                        //     true_answer_content.appendChild(p);
                        // }

                        // var id = questionContent.id;
                        // var userAnswer = getSubjectiveAnswer(id);
                        var userAnswer = questionContent.userAnswer;
                        if (userAnswer.length === 0) {
                            var span = document.createElement("span");
                            span.className = "user_answer false";
                            span.innerText = "未作答";
                            user_answer_content.appendChild(span);
                        } else {
                            var c = document.createElement("div");
                            c.className = "editContent";
                            user_answer_content.appendChild(c);

                            EditViewer.createNew(c).render(userAnswer);
                        }
                    }

                    // 解析
                    var examAnalysis = document.createElement("div");
                    examAnalysis.className = "examAnalysis";
                    content.appendChild(examAnalysis);

                    var p = document.createElement("p");
                    p.className = "analysis_text";
                    p.innerText = "解析:";
                    examAnalysis.appendChild(p);

                    var div = document.createElement("div");
                    div.className = "analysis_content";
                    examAnalysis.appendChild(div);

                    showParagraph(analysis, div);
                    // for (var i = 0; i < analysis.length; i++) {
                    //     p = document.createElement("p");
                    //     div.appendChild(p);
                    //     if (checkContent(analysis[i])) {
                    //         var img = document.createElement("img");
                    //         img.src = analysis[i];
                    //         bindImageSwape(img);
                    //         p.appendChild(img);
                    //     } else {
                    //         p.innerText = analysis[i];
                    //     }
                    // }
                }

                var examFooter = document.createElement("div");
                examFooter.className = "examFooter";
                content.appendChild(examFooter);



                // 上一题
                if (qn !== 0) {
                    var pre = document.createElement("a");
                    pre.className = "pre";
                    pre.href = "javascript:;";
                    pre.innerHTML = "<i></i>";
                    pre.onclick = function() {
                        viewAnswerSheet(obj, o, answer_sheet, content, null, qn - 1);
                        viewPaper(obj, o, answer_sheet, content, qn - 1);
                    };
                    examFooter.appendChild(pre);
                }

                // 下一题
                if (qn !== (obj.length - 1)) {
                    var next = document.createElement("a");
                    next.className = "next";
                    next.href = "javascript:;";
                    next.innerHTML = "<i></i>";
                    next.onclick = function() {
                        //shandy
                        // viewAnswerSheet(obj, o, answer_sheet, content, qn + 1);
                        viewPaper(obj, o, answer_sheet, content, qn + 1);
                    };
                    examFooter.appendChild(next);
                }
            }
        };
        // 综合题显示答案
        var showSynthesisUI = function(content, answer_sheet, examBody, obj, synthesisObj, qn, q) {
            examBody.innerHTML = "";
            var type = synthesisObj.question[q].type;
            var analysis = synthesisObj.question[q].analysis.split("\\n");
            if ((type !== 4) && (type !== 6)) {
                var choice = synthesisObj.question[q].choice.split("\\n");
                var a = handleAnswer(synthesisObj.question[q].answer, choice.length);
                var userAnswer = handleAnswer(synthesisObj.question[q].userAnswer, choice.length);

                var c = 0;
                for (var i = 0; i < a.length; i++) {
                    if (parseInt(a[i]) === 1) {
                        c++;
                    }
                }
            } else {
                var a = synthesisObj.question[q].answer.split("\\n");
            }
            var littleQuestionTitle = document.createElement("div");
            littleQuestionTitle.className = "littleQuestionTitle";
            examBody.appendChild(littleQuestionTitle);

            // 小题干
            var bodyData = synthesisObj.question[q].body.split("\\n");
            showParagraph(bodyData, littleQuestionTitle);
            // for (var i = 0; i < bodyData.length; i++) {
            //     p = document.createElement("p");
            //     if (checkContent(bodyData[i])) {
            //         var img = document.createElement("img");
            //         img.src = bodyData[i];
            //         bindImageSwape(img);
            //         p.appendChild(img);
            //     } else {
            //         p.innerText = bodyData[i];
            //     }
            //     littleQuestionTitle.appendChild(p);
            // }

            var littleQuestionChoice = document.createElement("ul");
            littleQuestionChoice.className = "littleQuestionChoice";
            examBody.appendChild(littleQuestionChoice);

            // 选项
            var choice = synthesisObj.question[q].choice.split("\\n");
            var isEmpty = true;
            for (var i = 0; i < choice.length; i++) {
                if (choice[i] !== "") {
                    isEmpty = false;
                    break;
                }
            }
            if ((choice.length !== 2) && (isEmpty === false)) {
                for (var i = 0; i < choice.length; i++) {
                    var li = document.createElement("li");

                    var span = document.createElement("span");
                    span.className = "choice";
                    span.innerText = String.fromCharCode(65 + i) + ". " + choice[i];
                    li.appendChild(span);

                    littleQuestionChoice.appendChild(li);
                }
            }

            // 答案
            var examChoice = document.createElement("div");
            examChoice.className = "examChoice";
            examBody.appendChild(examChoice);

            var examChoiceContent = document.createElement("div");
            examChoiceContent.className = "examChoiceContent";
            examChoice.appendChild(examChoiceContent);

            var true_answer_content = document.createElement("div");
            true_answer_content.className = "true_answer_content";
            var span = document.createElement("span");
            span.className = "text";
            span.innerText = "正确答案：";
            true_answer_content.appendChild(span);
            examChoiceContent.appendChild(true_answer_content);

            // 我的答案
            var user_answer_content = document.createElement("div");
            user_answer_content.className = "user_answer_content";
            var span = document.createElement("span");
            span.className = "text";
            span.innerText = "我的答案：";
            user_answer_content.appendChild(span);
            examChoiceContent.appendChild(user_answer_content);

            if ((type !== 4) && (type !== 6)) {
                if (a.length !== 2) {
                    for (var i = 0; i < a.length; i++) {
                        if (parseInt(a[i]) === 1) {
                            var span = document.createElement("span");
                            span.className = "true_answer";
                            span.innerText = String.fromCharCode(65 + i);
                            true_answer_content.appendChild(span);
                        }
                    }
                } else {
                    for (var i = 0; i < a.length; i++) {
                        if (parseInt(a[i]) === 1) {
                            var span = document.createElement("span");
                            span.className = "true_answer";
                            true_answer_content.appendChild(span);
                            span.innerText = "对";
                            if (String.fromCharCode(65 + i) === "B") {
                                span.innerText = "错";
                            }
                        }
                    }
                }



                // 判断是否做对
                var c = true;
                if (userAnswer.length === a.length) {
                    for (var i = 0; i < userAnswer.length; i++) {
                        if (parseInt(userAnswer[i]) !== parseInt(a[i])) {
                            c = false;
                            break;
                        }
                    }
                } else {
                    c = false;
                }

                var flag = true;
                for (var i = 0; i < userAnswer.length; i++) {
                    if (parseInt(userAnswer[i]) !== 0) {
                        flag = false;
                        break
                    }
                }
                if (flag === false) {
                    for (var j = 0; j < userAnswer.length; j++) {
                        if (parseInt(userAnswer[j]) === 1) {
                            span = document.createElement("span");
                            span.className = "user_answer";
                            span.innerText = String.fromCharCode(65 + j);
                            user_answer_content.appendChild(span);
                            if (choice.length !== 2) {
                                // p.innerText ="第" + (qn + 1) + "题 (单选题)";
                                span.innerText = String.fromCharCode(65 + j);
                            } else {
                                // p.innerText ="第" + (qn + 1) + "题 (判断题)";
                                if (String.fromCharCode(65 + j) === "B") {
                                    span.innerText = "错";
                                } else if (String.fromCharCode(65 + j) === "A") {
                                    span.innerText = "对";
                                }
                            }
                            if (c === false) {
                                span.className += " false";
                            } else {
                                span.className += " true";
                            }
                        }
                    }
                } else {
                    var span = document.createElement("span");
                    span.className = "user_answer false";
                    span.innerText = "未作答";
                    user_answer_content.appendChild(span);
                }
            } else {
                showParagraph(a, true_answer_content, "trueAnswer");
                // for (var i = 0; i < a.length; i++) {
                //     var p = document.createElement("p");
                //     p.className = "trueAnswer";
                //     if (checkContent(a[i])) {
                //         var img = document.createElement("img");
                //         img.src = a[i];
                //         bindImageSwape(img);
                //         p.appendChild(img);
                //     } else {
                //         p.innerText = a[i];
                //     }
                //     true_answer_content.appendChild(p);
                // }

                var userAnswer = synthesisObj.question[q].userAnswer;
                if (userAnswer === "") {
                    var span = document.createElement("span");
                    span.className = "user_answer false";
                    span.innerText = "未作答";
                    user_answer_content.appendChild(span);
                } else {
                    var c = document.createElement("div");
                    c.className = "editContent";
                    user_answer_content.appendChild(c);

                    EditViewer.createNew(c).render(userAnswer);
                }
            }
            // 解析
            var examAnalysis = document.createElement("div");
            examAnalysis.className = "examAnalysis";
            examBody.appendChild(examAnalysis);

            var p = document.createElement("p");
            p.className = "analysis_text";
            p.innerText = "解析:";
            examAnalysis.appendChild(p);

            var div = document.createElement("div");
            div.className = "analysis_content";
            examAnalysis.appendChild(div);

            showParagraph(analysis, div);
            // for (var i = 0; i < analysis.length; i++) {
            //     p = document.createElement("p");
            //     div.appendChild(p);
            //     if (checkContent(analysis[i])) {
            //         var img = document.createElement("img");
            //         img.src = analysis[i];
            //         bindImageSwape(img);
            //         p.appendChild(img);
            //     } else {
            //         p.innerText = analysis[i];
            //     }
            // }
        };

        // 发送主观题答案
        var postSubjectAnswer = function(questionID, s, onCallback) {
            space.answerExamQuestion(instance.meetingID, instance.examID, questionID, LZString.compressToBase64(s), onCallback);
        };

        // 获取主观题答案
        var getSubjectiveAnswer = function(questionID) {
            var subjective = localStorage.getItem("subjective");
            if (subjective !== null) {
                var subjectiveObj = eval("(" + subjective + ")");
                if (subjectiveObj[instance.examID] !== undefined) {
                    if (subjectiveObj[instance.examID][questionID] !== undefined) {
                        var s = "";
                        var r = decodeURIComponent(subjectiveObj[instance.examID][questionID]);
                        try {
                            s = LZString.decompressFromBase64(r);
                        } catch (e) {
                            s = null;
                        }
                        if (s === null) {
                            s = r;
                        }
                        return s;
                    } else {
                        return "";
                    }
                } else {
                    return "";
                }
            } else {
                return "";
            }
        };

        // 结束测试-查看答案
        var handleAnswer = function(d, l) {
            var a = 0x01;
            var b = "";
            for (var i = 0; i < 8; i++) {
                if (a === (d & a)) {
                    b += "1";
                } else {
                    b += "0";
                }
                a = (a << 1);
            }
            return b.split("").splice(0, l);
        };

        var showParagraph = function(arr, parent, className) {
            // Check inputs.
            if (!arr || arr.length === 0 || !parent) {
                return;
            }

            // Process each line in the array, respectively.
            for (var i = 0; i < arr.length; i ++) {

                // Check whether it is an image.
                var s = arr[i];
                var isLink = false;
                if (s.indexOf("http://") === 0) {
                    s = s.substr(5);
                    isLink = true;
                } else if (s.indexOf("https://") === 0) {
                    s = s.substr(6);
                    isLink = true;
                } else if (s.indexOf("//") === 0 || s.indexOf("data:image/") === 0) {
                    isLink = true;
                }

                // Construct a document element,
                //   and then append it to the parent.
                if (isLink === true) {
                    (function() {
                        var img = document.createElement("img");
                        img.src = s;
                        img.style.zoom = "1.0";

                        img.onclick = function(evt) {
                            evt.stopPropagation();

                            switch (this.style.zoom) {
                                case "1":
                                    this.style.zoom = "1.5";
                                    break;

                                default:
                                    this.style.zoom = "1";
                                    break;
                            }
                        };
                        parent.appendChild(img);
                    })();
                } else {
                    var p = document.createElement("p");
                    if (className) {
                        p.className = className;
                    }
                    p.innerText = s;
                    parent.appendChild(p);
                }
            }
        };

        return instance;
    }
};